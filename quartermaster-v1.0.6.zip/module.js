var V = Object.defineProperty;
var Q = (r, e, o) => e in r ? V(r, e, { enumerable: !0, configurable: !0, writable: !0, value: o }) : r[e] = o;
var S = (r, e, o) => Q(r, typeof e != "symbol" ? e + "" : e, o);
const v = "dolmenwood-party-inventory", R = {
  INVENTORY: "inventory",
  TRANSACTION_LOG: "transactionLog"
}, B = {
  PARTY_OVERVIEW: `modules/${v}/templates/party-overview.hbs`,
  PLAYER_INVENTORY: `modules/${v}/templates/player-inventory.hbs`,
  SHOP: `modules/${v}/templates/shop.hbs`,
  PARTIALS: {
    INVENTORY_ZONE: `modules/${v}/templates/partials/inventory-zone.hbs`,
    ITEM_ROW: `modules/${v}/templates/partials/item-row.hbs`,
    COIN_DISPLAY: `modules/${v}/templates/partials/coin-display.hbs`,
    ENCUMBRANCE_BAR: `modules/${v}/templates/partials/encumbrance-bar.hbs`,
    TRANSACTION_LOG: `modules/${v}/templates/partials/transaction-log.hbs`,
    PARTY_SUMMARY: `modules/${v}/templates/partials/party-summary.hbs`
  }
}, q = {
  PURCHASE_ITEM: "purchaseItem",
  GM_GRANT: "gmGrant",
  GM_REMOVE: "gmRemove",
  GIVE_COINS: "giveCoins",
  REQUEST_REFRESH: "requestRefresh"
}, x = {
  SHOP_STATE: "shopState"
}, H = `module.${v}`, Y = [
  [0, 3, 40],
  [4, 5, 30],
  [6, 7, 20],
  [8, 10, 10]
], j = [
  [0, 10, 40],
  [11, 12, 30],
  [13, 14, 20],
  [15, 16, 10]
];
function $(r, e) {
  for (const [o, t, n] of e)
    if (r >= o && r <= t) return n;
  return 10;
}
function L(r, e) {
  var m;
  let o = 0, t = 0, n = 0;
  for (const p of r.items) {
    const A = e.get(p.definitionId), G = ((m = p.customDefinition) == null ? void 0 : m.size) ?? (A == null ? void 0 : A.size) ?? "normal", k = p.quantity;
    p.zone === "tiny" ? n += k : p.zone === "equipped" ? G === "tiny" || (G === "normal" ? o += k : G === "large" && (o += k * 2)) : p.zone === "stowed" && (G === "tiny" ? n += k : G === "normal" ? t += k : G === "large" && (t += k * 2));
  }
  const s = Math.max(0, 10 - n), a = Math.max(0, n - 10);
  t += Math.ceil(a / 10);
  const { cp: c, sp: i, gp: l, pp: d } = r.coins, u = c + i + l + d, f = u > 0 ? Math.ceil(u / 100) : 0;
  t += f;
  const g = $(o, Y), y = $(t, j), b = Math.min(g, y);
  let w = "none";
  return g < y ? w = "equipped" : y < g ? w = "stowed" : b < 40 && (w = "both"), {
    equippedSlots: o,
    stowedSlots: t,
    equippedSpeed: g,
    stowedSpeed: y,
    finalSpeed: b,
    bottleneck: w,
    tinyCount: n,
    freeTinySlots: s,
    tinyOverflow: a,
    coinSlots: f
  };
}
function Z(r) {
  switch (r) {
    case 40:
      return "speed-green";
    case 30:
      return "speed-yellow";
    case 20:
      return "speed-orange";
    case 10:
      return "speed-red";
  }
}
function K() {
  Handlebars.registerHelper("eq", (r, e) => r === e), Handlebars.registerHelper("neq", (r, e) => r !== e), Handlebars.registerHelper("gt", (r, e) => r > e), Handlebars.registerHelper("lt", (r, e) => r < e), Handlebars.registerHelper(
    "formatCost",
    (r, e) => `${r} ${e}`
  ), Handlebars.registerHelper(
    "speedColor",
    (r) => Z(r)
  ), Handlebars.registerHelper(
    "equippedBarWidth",
    (r) => Math.min(100, r / 10 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper(
    "stowedBarWidth",
    (r) => Math.min(100, r / 16 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper("bottleneckLabel", (r) => {
    switch (r) {
      case "equipped":
        return "Equipped";
      case "stowed":
        return "Stowed";
      case "both":
        return "Both";
      default:
        return "";
    }
  }), Handlebars.registerHelper(
    "coinTotal",
    (r, e, o, t) => {
      const n = [];
      return t > 0 && n.push(`${t} pp`), o > 0 && n.push(`${o} gp`), e > 0 && n.push(`${e} sp`), r > 0 && n.push(`${r} cp`), n.length > 0 ? n.join(", ") : "0 gp";
    }
  ), Handlebars.registerHelper("sizeLabel", (r) => {
    switch (r) {
      case "tiny":
        return "Tiny";
      case "normal":
        return "Normal";
      case "large":
        return "Large";
      default:
        return r;
    }
  }), Handlebars.registerHelper("slotCost", (r) => {
    switch (r) {
      case "tiny":
        return "0 slots";
      case "normal":
        return "1 slot";
      case "large":
        return "2 slots";
      default:
        return "-";
    }
  }), Handlebars.registerHelper("itemIcon", (r) => {
    switch ((r ?? "").toLowerCase()) {
      case "adventuring gear":
        return "fa-compass";
      case "ammunition":
        return "fa-bullseye";
      case "armour":
        return "fa-shield-halved";
      case "arrows":
        return "fa-arrow-up";
      case "camping and travel":
        return "fa-tent";
      case "clothing":
        return "fa-shirt";
      case "containers":
        return "fa-box";
      case "holy items":
        return "fa-cross";
      case "light":
        return "fa-lightbulb";
      case "melee":
        return "fa-hand-fist";
      case "missile":
        return "fa-crosshairs";
      case "quarrels":
        return "fa-crosshairs";
      case "stones":
        return "fa-circle";
      case "tools":
        return "fa-wrench";
      case "weapons":
        return "fa-gavel";
      default:
        return "fa-sack";
    }
  });
}
async function J() {
  await loadTemplates({
    "transaction-log": B.PARTIALS.TRANSACTION_LOG,
    "inventory-zone": B.PARTIALS.INVENTORY_ZONE,
    "item-row": B.PARTIALS.ITEM_ROW,
    "coin-display": B.PARTIALS.COIN_DISPLAY,
    "encumbrance-bar": B.PARTIALS.ENCUMBRANCE_BAR,
    "party-summary": B.PARTIALS.PARTY_SUMMARY
  });
}
function X(r) {
  return {
    actorId: r,
    coins: { cp: 0, sp: 0, gp: 0, pp: 0 },
    items: []
  };
}
class h {
  static getInventory(e) {
    return e.getFlag(v, R.INVENTORY) ?? X(e.id ?? "");
  }
  static async setInventory(e, o) {
    await e.setFlag(v, R.INVENTORY, o);
  }
  static async updateInventory(e, o) {
    const t = this.getInventory(e), n = o(structuredClone(t));
    await this.setInventory(e, n);
  }
  static getTransactions() {
    return game.settings.get(v, R.TRANSACTION_LOG) ?? [];
  }
  static async appendTransaction(e) {
    const o = this.getTransactions();
    o.push(e);
    const t = o.slice(-200);
    await game.settings.set(v, R.TRANSACTION_LOG, t);
  }
}
class C {
  static initialize() {
    game.socket.on(
      H,
      (e) => C.handleIncoming(e)
    );
  }
  /**
   * Emit a socket event to all clients (including ourselves, handled locally too).
   */
  static emit(e, o) {
    const t = {
      event: e,
      data: o,
      userId: game.user.id
    };
    game.socket.emit(H, t);
  }
  static handleIncoming(e) {
    var t, n, s, a;
    const o = game;
    switch (e.event) {
      case q.GM_GRANT:
        (t = o.user) != null && t.isGM && C.onGMGrant(e.data);
        break;
      case q.GM_REMOVE:
        (n = o.user) != null && n.isGM && C.onGMRemove(e.data);
        break;
      case q.PURCHASE_ITEM:
        (s = o.user) != null && s.isGM && C.onPurchase(e.data);
        break;
      case q.GIVE_COINS:
        (a = o.user) != null && a.isGM && C.onGiveCoins(e.data);
        break;
      case q.REQUEST_REFRESH:
        C.onRequestRefresh();
        break;
    }
  }
  static async onGMGrant(e) {
    var s;
    const o = (s = game.actors) == null ? void 0 : s.get(e.actorId);
    if (!o) return;
    const t = {
      ...e.item,
      id: foundry.utils.randomID()
    };
    await h.updateInventory(o, (a) => (a.items.push(t), a));
    const n = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "gm_grant",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: t.definitionId, name: t.name, quantity: t.quantity }],
      coinsDelta: []
    };
    await h.appendTransaction(n), C.emit(q.REQUEST_REFRESH, {});
  }
  static async onGMRemove(e) {
    var n;
    const o = (n = game.actors) == null ? void 0 : n.get(e.actorId);
    if (!o) return;
    let t;
    if (await h.updateInventory(o, (s) => {
      const a = s.items.findIndex((c) => c.id === e.itemId);
      if (a !== -1) {
        const [c] = s.items.splice(a, 1);
        t = { definitionId: c.definitionId, name: c.name, quantity: c.quantity };
      }
      return s;
    }), t) {
      const s = {
        id: foundry.utils.randomID(),
        timestamp: Date.now(),
        type: "gm_remove",
        fromActorId: e.actorId,
        toActorId: "shop",
        items: [t],
        coinsDelta: []
      };
      await h.appendTransaction(s);
    }
    C.emit(q.REQUEST_REFRESH, {});
  }
  static async onPurchase(e) {
    var n;
    const o = (n = game.actors) == null ? void 0 : n.get(e.actorId);
    if (!o) return;
    await h.updateInventory(o, (s) => {
      const a = (e.totalCost.cp ?? 0) + (e.totalCost.sp ?? 0) * 10 + (e.totalCost.gp ?? 0) * 100 + (e.totalCost.pp ?? 0) * 500, c = s.coins.cp + s.coins.sp * 10 + s.coins.gp * 100 + s.coins.pp * 500;
      if (c < a) return s;
      const i = c - a;
      return s.coins.pp = 0, s.coins.gp = Math.floor(i / 100), s.coins.sp = Math.floor(i % 100 / 10), s.coins.cp = i % 10, s.items.push({
        id: foundry.utils.randomID(),
        definitionId: e.definitionId,
        name: e.definitionId,
        // will be resolved by UI from catalog
        quantity: e.quantity,
        zone: e.zone,
        isSecret: !1,
        notes: ""
      }), s;
    });
    const t = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "purchase",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: e.definitionId, name: e.definitionId, quantity: e.quantity }],
      coinsDelta: [
        {
          actorId: e.actorId,
          cp: -e.totalCost.cp,
          sp: -e.totalCost.sp,
          gp: -e.totalCost.gp,
          pp: -e.totalCost.pp
        }
      ]
    };
    await h.appendTransaction(t), C.emit(q.REQUEST_REFRESH, {});
  }
  static async onGiveCoins(e) {
    var a, c;
    const o = game, t = (a = o.actors) == null ? void 0 : a.get(e.fromActorId), n = (c = o.actors) == null ? void 0 : c.get(e.toActorId);
    if (!t || !n) return;
    await h.updateInventory(t, (i) => (i.coins.cp = Math.max(0, i.coins.cp - e.cp), i.coins.sp = Math.max(0, i.coins.sp - e.sp), i.coins.gp = Math.max(0, i.coins.gp - e.gp), i.coins.pp = Math.max(0, i.coins.pp - e.pp), i)), await h.updateInventory(n, (i) => (i.coins.cp += e.cp, i.coins.sp += e.sp, i.coins.gp += e.gp, i.coins.pp += e.pp, i));
    const s = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "trade",
      fromActorId: e.fromActorId,
      toActorId: e.toActorId,
      items: [],
      coinsDelta: [
        { actorId: e.fromActorId, cp: -e.cp, sp: -e.sp, gp: -e.gp, pp: -e.pp },
        { actorId: e.toActorId, cp: e.cp, sp: e.sp, gp: e.gp, pp: e.pp }
      ]
    };
    await h.appendTransaction(s), C.emit(q.REQUEST_REFRESH, {});
  }
  static onRequestRefresh() {
    var e, o;
    for (const t of Object.values(((e = foundry.applications) == null ? void 0 : e.instances) ?? {}))
      (t.id ?? "").startsWith("dolmenwood-") && ((o = t.render) == null || o.call(t));
  }
}
const T = [
  // ─── ARMOUR ───────────────────────────────────────────────────────────────
  {
    id: "unarmoured",
    name: "Unarmoured",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "gp" },
    weight: 0,
    description: "No armour. AC 10.",
    qualities: ["AC 10"],
    tags: [],
    isCustom: !1
  },
  {
    id: "leather-armour",
    name: "Leather Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 200,
    description: "Light armour made of hardened leather. AC 12.",
    qualities: ["AC 12"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bark-armour",
    name: "Bark Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 300,
    description: "Armour crafted from treated tree bark. AC 13.",
    qualities: ["AC 13"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chainmail",
    name: "Chainmail",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 400,
    description: "Interlocking metal rings. AC 14.",
    qualities: ["AC 14"],
    tags: [],
    isCustom: !1
  },
  {
    id: "pinecone-armour",
    name: "Pinecone Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 400,
    description: "Armour fashioned from overlapping pinecone scales. AC 15.",
    qualities: ["AC 15"],
    tags: [],
    isCustom: !1
  },
  {
    id: "plate-mail",
    name: "Plate Mail",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 60, currency: "gp" },
    weight: 500,
    description: "Heavy plate armour. AC 16.",
    qualities: ["AC 16"],
    tags: [],
    isCustom: !1
  },
  {
    id: "full-plate",
    name: "Full Plate",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1e3, currency: "gp" },
    weight: 700,
    description: "The finest and heaviest plate armour. AC 17.",
    qualities: ["AC 17"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shield",
    name: "Shield",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A wooden or metal shield. AC +1.",
    qualities: ["AC +1"],
    tags: [],
    isCustom: !1
  },
  // ─── WEAPONS ──────────────────────────────────────────────────────────────
  {
    id: "battle-axe",
    name: "Battle Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 100,
    description: "A heavy two-handed axe. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "club",
    name: "Club",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 20,
    description: "A heavy wooden club. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "crossbow",
    name: "Crossbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 50,
    description: "A mechanical ranged weapon. 1d8 damage.",
    qualities: ["1d8", "Missile (80/160/240)", "Reload", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "dagger",
    name: "Dagger",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "A short blade useful in melee and as a thrown weapon. 1d4 damage.",
    qualities: ["Melee", "1d4", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "hand-axe",
    name: "Hand Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 20,
    description: "A small axe, usable in melee or thrown. 1d6 damage.",
    qualities: ["Melee", "1d6", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial",
    name: "Holy Water (Vial)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "Blessed water, effective against undead when thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "lance",
    name: "Lance",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !0,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 100,
    description: "A long cavalry weapon. 1d6 damage. Cannot be stowed.",
    qualities: ["Brace", "Charge", "Melee", "1d6", "Reach"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longbow",
    name: "Longbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 40,
    description: "A tall war bow with long range. 1d8 damage.",
    qualities: ["1d8", "Missile (70/140/210)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longsword",
    name: "Longsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "A versatile one-handed sword. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "mace",
    name: "Mace",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy-headed bludgeoning weapon. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask-burning",
    name: "Oil Flask (Burning)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of oil set alight and thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "polearm",
    name: "Polearm",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 140,
    description: "A long hafted weapon with a blade or head. 1d10 damage.",
    qualities: ["Brace", "Melee", "1d10", "Reach", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortbow",
    name: "Shortbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A compact bow for skirmishing. 1d6 damage.",
    qualities: ["1d6", "Missile (50/100/150)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortsword",
    name: "Shortsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 20,
    description: "A short, light blade. 1d6 damage.",
    qualities: ["Melee", "1d6"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling",
    name: "Sling",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 10,
    description: "A simple ranged weapon using stones. 1d4 damage.",
    qualities: ["1d4", "Missile (40/80/160)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "spear",
    name: "Spear",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 30,
    description: "A thrusting weapon, useful in melee and as a thrown weapon. 1d6 damage.",
    qualities: ["Brace", "Melee", "1d6", "Missile (20/40/60)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "staff",
    name: "Staff",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 40,
    description: "A long wooden staff. 1d6 damage.",
    qualities: ["Melee", "1d6", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "torch-flaming",
    name: "Torch (Flaming)",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 15,
    description: "A lit torch used as an improvised weapon. 1d4 damage. Sold in sets of 3.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "two-handed-sword",
    name: "Two-Handed Sword",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 140,
    description: "A massive greatsword requiring both hands. 1d10 damage.",
    qualities: ["Melee", "1d10", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "war-hammer",
    name: "War Hammer",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy hammer for smashing armour. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  // ─── AMMUNITION ───────────────────────────────────────────────────────────
  {
    id: "arrows-quiver",
    name: "Arrows (Quiver of 20)",
    category: "Ammunition",
    subcategory: "Arrows",
    size: "normal",
    cannotBeStowed: !1,
    unit: "quiver",
    cost: { amount: 5, currency: "cp" },
    weight: 20,
    description: "A quiver of 20 arrows for use with bows.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quarrels-case",
    name: "Quarrels (Case of 20)",
    category: "Ammunition",
    subcategory: "Quarrels",
    size: "normal",
    cannotBeStowed: !1,
    unit: "case",
    cost: { amount: 10, currency: "cp" },
    weight: 20,
    description: "A case of 20 crossbow quarrels.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling-stones",
    name: "Sling Stones",
    category: "Ammunition",
    subcategory: "Stones",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "cp" },
    weight: 1,
    description: "Smooth stones for use with a sling. Free to acquire.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CONTAINERS ────────────────────────────────────────
  {
    id: "backpack",
    name: "Backpack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A sturdy canvas backpack. Capacity: 400 coins.",
    qualities: ["Capacity: 400 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "barrel",
    name: "Barrel",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 70,
    description: "A wooden barrel. Capacity: 320 pints.",
    qualities: ["Capacity: 320 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "belt-pouch",
    name: "Belt Pouch",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A small leather pouch worn on the belt. Capacity: 50 coins.",
    qualities: ["Capacity: 50 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bucket",
    name: "Bucket",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "A wooden or metal bucket. Capacity: 40 pints.",
    qualities: ["Capacity: 40 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-large",
    name: "Casket (Iron, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 400,
    description: "A large iron strongbox. Capacity: 800 coins.",
    qualities: ["Capacity: 800 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-small",
    name: "Casket (Iron, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A small iron strongbox. Capacity: 250 coins.",
    qualities: ["Capacity: 250 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-large",
    name: "Chest (Wooden, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 200,
    description: "A large wooden chest. Capacity: 1000 coins.",
    qualities: ["Capacity: 1000 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-small",
    name: "Chest (Wooden, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A small wooden chest. Capacity: 300 coins.",
    qualities: ["Capacity: 300 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sack",
    name: "Sack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A large cloth sack. Capacity: 600 coins.",
    qualities: ["Capacity: 600 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "scroll-case",
    name: "Scroll Case",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A protective tube for scrolls and maps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "vial-glass",
    name: "Vial (Glass)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small glass vial. Capacity: 0.5 pint.",
    qualities: ["Capacity: 0.5 pint"],
    tags: [],
    isCustom: !1
  },
  {
    id: "waterskin",
    name: "Waterskin",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A leather flask for carrying water. Capacity: 2 pints.",
    qualities: ["Capacity: 2 pints"],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — LIGHT ─────────────────────────────────────────────
  {
    id: "candles-10",
    name: "Candles (10)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Ten tallow candles, providing dim light for 1 hour each.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-hooded",
    name: "Lantern (Hooded)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 20,
    description: "A lantern with adjustable hood to control light.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-bullseye",
    name: "Lantern (Bullseye)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 20,
    description: "A lantern that focuses light in a cone.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask",
    name: "Oil (Flask)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of lamp oil, fueling a lantern for 4 hours.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tinder-box",
    name: "Tinder Box",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "Steel, flint, and tinder for starting fires.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "torches-3",
    name: "Torches (3)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Three wooden torches, each burning for 1 hour.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CAMPING AND TRAVEL ────────────────────────────────
  {
    id: "bedroll",
    name: "Bedroll",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 70,
    description: "A rolled sleeping mat and blanket.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "cooking-pots",
    name: "Cooking Pots",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 100,
    description: "A set of iron cooking pots for camp meals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "firewood-bundle",
    name: "Firewood (Bundle, 8 hours)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 200,
    description: "A bundle of firewood sufficient for 8 hours of burning.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "fishing-rod-and-tackle",
    name: "Fishing Rod and Tackle",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A rod, line, and hook for fishing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-preserved",
    name: "Rations (Preserved, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Hard tack, jerky, and dried goods lasting one day.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-fresh",
    name: "Rations (Fresh, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Fresh food for one day — must be consumed within a few days.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tent",
    name: "Tent",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "A canvas tent sheltering up to two people.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — HOLY ITEMS ────────────────────────────────────────
  {
    id: "holy-symbol-gold",
    name: "Holy Symbol (Gold)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 20,
    description: "A golden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-silver",
    name: "Holy Symbol (Silver)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A silver holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-wooden",
    name: "Holy Symbol (Wooden)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A carved wooden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial-gear",
    name: "Holy Water (Vial)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "A vial of blessed water, effective against undead.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — MISCELLANEOUS TOOLS ───────────────────────────────
  {
    id: "bell-miniature",
    name: "Bell (Miniature)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A small bell useful for alarms and signals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "block-and-tackle",
    name: "Block and Tackle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "A pulley system for hoisting heavy loads.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "caltrops-bag",
    name: "Caltrops (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Metal spikes scattered to slow pursuit.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chain-10ft",
    name: "Chain (10' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 100,
    description: "Ten feet of iron chain.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chalk-10-sticks",
    name: "Chalk (10 Sticks)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "Ten sticks of chalk for marking walls and floors.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chisel",
    name: "Chisel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A metal chisel for cutting stone and wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "crowbar",
    name: "Crowbar",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "An iron pry bar for forcing doors and shifting stones.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "grappling-hook",
    name: "Grappling Hook",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "An iron hook for climbing walls and crossing gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-small",
    name: "Hammer (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 15,
    description: "A small hammer for driving spikes and basic carpentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-sledgehammer",
    name: "Hammer (Sledgehammer)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy hammer for breaking rock and forcing barriers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "ink-vial",
    name: "Ink (Vial)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 8, currency: "gp" },
    weight: 5,
    description: "A vial of black writing ink.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "iron-spikes-12",
    name: "Iron Spikes (12)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A dozen iron spikes for pitons, door-spiking, and general use.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lock",
    name: "Lock",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "An iron padlock with key.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "magnifying-glass",
    name: "Magnifying Glass",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 5,
    description: "A glass lens for examining small objects and starting fires in sunlight.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "manacles",
    name: "Manacles",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 30,
    description: "Iron restraints with a lock for binding prisoners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "marbles-bag",
    name: "Marbles (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "Glass marbles scattered to trip pursuers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mining-pick",
    name: "Mining Pick",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy pick for breaking rock.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mirror-small",
    name: "Mirror (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 5,
    description: "A small steel mirror for signalling and peeking around corners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-stringed",
    name: "Musical Instrument (Stringed)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 30,
    description: "A lute, lyre, or similar stringed instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-wind",
    name: "Musical Instrument (Wind)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A flute, recorder, or similar wind instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "paper-parchment-2-sheets",
    name: "Paper or Parchment (2 Sheets)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 2,
    description: "Two sheets of paper or parchment for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "pole-10ft",
    name: "Pole (10' Long Wooden)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "A ten-foot wooden pole for prodding, vaulting, and bridging gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quill",
    name: "Quill",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A feather quill for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-50ft",
    name: "Rope (50' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "Fifty feet of hempen rope.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-ladder-25ft",
    name: "Rope Ladder (25' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 50,
    description: "A twenty-five foot rope ladder.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "saw",
    name: "Saw",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A toothed blade for cutting wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "shovel",
    name: "Shovel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "An iron-headed shovel for digging.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "spell-book-blank",
    name: "Spell Book (Blank)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 30,
    description: "A blank tome for recording spells.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "thieves-tools",
    name: "Thieves' Tools",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 10,
    description: "A set of picks, tension wrenches, and other tools for opening locks.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "twine-100ft",
    name: "Twine (100' Ball)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A ball of one hundred feet of thin twine.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "whistle",
    name: "Whistle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small metal whistle for signalling.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CLOTHING ──────────────────────────────────────────
  {
    id: "clothes-common",
    name: "Clothes (Common)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Plain, practical everyday clothing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-extravagant",
    name: "Clothes (Extravagant)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 60,
    description: "Elaborate clothing in silk and velvet, befitting a noble.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-fine",
    name: "Clothes (Fine)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 40,
    description: "Quality clothing suitable for merchants and minor gentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "habit-friars",
    name: "Habit (Friar's)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "A simple hooded robe worn by friars and mendicants.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "robes-ritual",
    name: "Robes (Ritual)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "Ceremonial robes worn during religious rites.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "winter-cloak",
    name: "Winter Cloak",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A heavy wool cloak for cold weather.",
    qualities: [],
    tags: [],
    isCustom: !1
  }
], W = new Map(
  T.map((r) => [r.id, r])
);
[
  ...new Set(T.map((r) => r.category))
];
[
  ...new Set(T.flatMap((r) => r.tags))
].sort();
class M {
  static getDefinition(e) {
    return W.get(e);
  }
  static getAllDefinitions() {
    return T;
  }
  static getMap() {
    return W;
  }
  static getByCategory(e) {
    return T.filter((o) => o.category === e);
  }
  static getBySubcategory(e) {
    return T.filter((o) => o.subcategory === e);
  }
  /** Returns items that have ALL of the specified tags, plus items with no tags (always visible). */
  static filterByTags(e) {
    return e.length === 0 ? T : T.filter(
      (o) => o.tags.length === 0 || e.every((t) => o.tags.includes(t))
    );
  }
  static getCategories() {
    return [...new Set(T.map((e) => e.category))];
  }
  static getSubcategories(e) {
    const o = e ? T.filter((t) => t.category === e) : T;
    return [...new Set(o.map((t) => t.subcategory))];
  }
  static getAllTags() {
    return [...new Set(T.flatMap((e) => e.tags))].sort();
  }
  /** Group catalog items by category, then subcategory */
  static groupedByCategoryAndSubcategory() {
    const e = {};
    for (const o of T)
      e[o.category] || (e[o.category] = {}), e[o.category][o.subcategory] || (e[o.category][o.subcategory] = []), e[o.category][o.subcategory].push(o);
    return e;
  }
}
const z = class z extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor() {
    super(...arguments);
    /** Currently selected target actor ID */
    S(this, "selectedActorId", null);
    /** Current search/filter text */
    S(this, "searchText", "");
    /** Only show items the selected actor can afford */
    S(this, "showAffordableOnly", !1);
  }
  async _prepareContext(o) {
    var g, y, b, w, m;
    const t = game, n = t.settings.get(v, x.SHOP_STATE), s = (((g = t.actors) == null ? void 0 : g.contents) ?? []).filter(
      (p) => {
        var A;
        return (((A = t.users) == null ? void 0 : A.contents) ?? []).some((G) => !G.isGM && p.testUserPermission(G, "OWNER"));
      }
    ), a = ((y = t.user) == null ? void 0 : y.isGM) ?? !1;
    a ? !this.selectedActorId && s.length > 0 && (this.selectedActorId = s[0].id ?? null) : this.selectedActorId = ((w = (b = t.user) == null ? void 0 : b.character) == null ? void 0 : w.id) ?? null;
    const c = this.selectedActorId ? (m = t.actors) == null ? void 0 : m.get(this.selectedActorId) : void 0, i = u ? u.coins.cp + u.coins.sp * 10 + u.coins.gp * 100 + u.coins.pp * 500 : 0;
    let l = M.filterByTags(n.activeTags);
    if (n.availableItems.length > 0 && (l = l.filter((p) => n.availableItems.includes(p.id))), this.searchText) {
      const p = this.searchText.toLowerCase();
      l = l.filter(
        (A) => A.name.toLowerCase().includes(p) || A.category.toLowerCase().includes(p) || A.subcategory.toLowerCase().includes(p)
      );
    }
    this.showAffordableOnly && u && (l = l.filter((p) => {
      const A = p.cost.currency === "cp" ? p.cost.amount : p.cost.currency === "sp" ? p.cost.amount * 10 : p.cost.currency === "gp" ? p.cost.amount * 100 : p.cost.amount * 500;
      return i >= A;
    }));
    const d = {};
    for (const p of l)
      d[p.category] || (d[p.category] = []), d[p.category].push(p);
    let u, f;
    return c && (u = h.getInventory(c), f = L(
      u,
      M.getMap()
    )), {
      shopState: n,
      allTags: M.getAllTags(),
      grouped: d,
      partyMembers: s,
      selectedActorId: this.selectedActorId,
      selectedActor: c,
      selectedInventory: u,
      selectedEncumbrance: f,
      searchText: this.searchText,
      isGM: a,
      showAffordableOnly: this.showAffordableOnly,
      availableCp: i
    };
  }
  _onRender(o, t) {
    var s, a;
    const n = this.element;
    (s = n.querySelector("#shop-target-actor")) == null || s.addEventListener(
      "change",
      (c) => {
        this.selectedActorId = c.target.value || null, this.render();
      }
    ), (a = n.querySelector("#shop-search")) == null || a.addEventListener(
      "input",
      (c) => {
        this.searchText = c.target.value, this.render();
      }
    );
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static _onToggleAffordable() {
    this.showAffordableOnly = !this.showAffordableOnly, this.render();
  }
  static async _onToggleTag(o, t) {
    const n = t.dataset.tag, s = game, a = s.settings.get(v, x.SHOP_STATE), c = a.activeTags.indexOf(n);
    c === -1 ? a.activeTags.push(n) : a.activeTags.splice(c, 1), await s.settings.set(v, x.SHOP_STATE, a), this.render();
  }
  static async _onPurchaseItem(o, t) {
    var y, b;
    const n = t.dataset.itemId, s = M.getDefinition(n);
    if (!s || !this.selectedActorId) return;
    const c = (y = game.actors) == null ? void 0 : y.get(this.selectedActorId);
    if (!c) return;
    const i = h.getInventory(c), l = i.coins.cp + i.coins.sp * 10 + i.coins.gp * 100 + i.coins.pp * 500, d = s.cost.currency === "cp" ? s.cost.amount : s.cost.currency === "sp" ? s.cost.amount * 10 : s.cost.currency === "gp" ? s.cost.amount * 100 : s.cost.amount * 500, u = l >= d;
    if (!await new Promise((w) => {
      new Dialog({
        title: "Purchase Item",
        content: `
          <p>Purchase <strong>${s.name}</strong> for <strong>${s.cost.amount} ${s.cost.currency}</strong>?</p>
          <p>Target: <strong>${c.name}</strong></p>
          ${u ? "" : '<p class="warning"><i class="fas fa-exclamation-triangle"></i> Insufficient funds! Proceed anyway (GM override)?</p>'}
          <div class="form-group">
            <label>Add to zone:</label>
            <select id="purchase-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
        `,
        buttons: {
          confirm: {
            label: u ? "Purchase" : "Override & Purchase",
            icon: `<i class="fas ${u ? "fa-shopping-cart" : "fa-exclamation-triangle"}"></i>`,
            callback: () => w(!0)
          },
          cancel: { label: "Cancel", callback: () => w(!1) }
        },
        default: "confirm"
      }).render(!0);
    })) return;
    const g = "stowed";
    await h.updateInventory(c, (w) => {
      if (u) {
        const m = l - d;
        w.coins.pp = Math.floor(m / 500), w.coins.gp = Math.floor(m % 500 / 100), w.coins.sp = Math.floor(m % 100 / 10), w.coins.cp = m % 10;
      }
      return w.items.push({
        id: foundry.utils.randomID(),
        definitionId: n,
        name: s.name,
        quantity: 1,
        zone: g,
        isSecret: !1,
        notes: ""
      }), w;
    }), (b = ui.notifications) == null || b.info(`Purchased ${s.name} for ${c.name}.`), this.render();
  }
  static _onGrantItem(o, t) {
    var a, c;
    const n = t.dataset.itemId, s = M.getDefinition(n);
    if (!s || !this.selectedActorId) {
      (a = ui.notifications) == null || a.warn("Select a party member first.");
      return;
    }
    C.emit(q.GM_GRANT, {
      actorId: this.selectedActorId,
      item: {
        definitionId: n,
        name: s.name,
        quantity: 1,
        zone: "stowed",
        isSecret: !1,
        notes: ""
      }
    }), (c = ui.notifications) == null || c.info(`Granted ${s.name}.`);
  }
  static _onAddCustomItem() {
    var t;
    if (!this.selectedActorId) {
      (t = ui.notifications) == null || t.warn("Select a party member first.");
      return;
    }
    const o = this.selectedActorId;
    new Dialog({
      title: "Add Custom Item",
      content: `
        <form>
          <div class="form-group">
            <label>Item Name</label>
            <input type="text" id="custom-name" placeholder="Custom item name" />
          </div>
          <div class="form-group">
            <label>Size</label>
            <select id="custom-size">
              <option value="tiny">Tiny (0 slots)</option>
              <option value="normal" selected>Normal (1 slot)</option>
              <option value="large">Large (2 slots)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="custom-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="custom-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
          <div class="form-group">
            <label>Secret?</label>
            <input type="checkbox" id="custom-secret" />
          </div>
        </form>
      `,
      buttons: {
        add: {
          label: "Grant Item",
          callback: (n) => {
            const s = n.find("#custom-name").val().trim();
            if (!s) return;
            const a = n.find("#custom-size").val(), c = Math.max(1, parseInt(n.find("#custom-qty").val(), 10) || 1), i = n.find("#custom-zone").val(), l = n.find("#custom-secret").prop("checked");
            C.emit(q.GM_GRANT, {
              actorId: o,
              item: {
                definitionId: "",
                name: s,
                quantity: c,
                zone: i,
                isSecret: l,
                notes: "",
                customDefinition: { size: a, isCustom: !0 }
              }
            });
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    }).render(!0);
  }
};
S(z, "DEFAULT_OPTIONS", {
  id: "dolmenwood-shop",
  window: {
    title: "Shop",
    resizable: !0
  },
  position: {
    width: 700,
    height: 640
  },
  classes: ["dolmenwood-party-inventory", "shop"],
  actions: {
    toggleTag: z._onToggleTag,
    toggleAffordable: z._onToggleAffordable,
    purchaseItem: z._onPurchaseItem,
    grantItem: z._onGrantItem,
    addCustomItem: z._onAddCustomItem
  }
}), S(z, "PARTS", {
  content: {
    template: B.SHOP
  }
});
let O = z;
const I = class I extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor(o, t) {
    super(t);
    S(this, "actor");
    this.actor = o;
  }
  get title() {
    return `${this.actor.name} — Inventory`;
  }
  async _prepareContext(o) {
    var y, b, w;
    const t = game, n = h.getInventory(this.actor), s = L(n, M.getMap()), a = ((y = t.user) == null ? void 0 : y.isGM) ?? !1, c = this.actor.isOwner, i = n.items.filter(
      (m) => !m.isSecret || a || c
    ), l = {
      tiny: i.filter((m) => m.zone === "tiny"),
      equipped: i.filter((m) => m.zone === "equipped"),
      stowed: i.filter((m) => m.zone === "stowed")
    }, d = (m) => m.map((p) => ({
      ...p,
      def: M.getDefinition(p.definitionId)
    })), u = (((b = t.actors) == null ? void 0 : b.contents) ?? []).filter(
      (m) => {
        var p;
        return m.id !== this.actor.id && (((p = t.users) == null ? void 0 : p.contents) ?? []).some((A) => !A.isGM && m.testUserPermission(A, "OWNER"));
      }
    ), f = (((w = t.actors) == null ? void 0 : w.contents) ?? []).filter(
      (m) => {
        var p;
        return (((p = t.users) == null ? void 0 : p.contents) ?? []).some((A) => !A.isGM && m.testUserPermission(A, "OWNER"));
      }
    ), g = F(f, a, t.user ?? null);
    return {
      actor: this.actor,
      actorId: this.actor.id,
      inventory: n,
      zones: {
        tiny: d(l.tiny),
        equipped: d(l.equipped),
        stowed: d(l.stowed)
      },
      encumbrance: s,
      isGM: a,
      isOwner: c,
      canEdit: a,
      // full edit: add/delete/move items, change coins — GM only
      canGive: c && !a,
      // give items/coins to others — player only
      partyMembers: u,
      partySummary: g,
      transactions: a ? h.getTransactions() : []
    };
  }
  _onRender(o, t) {
    const n = this.element;
    n.querySelectorAll(".item-zone-select").forEach((s) => {
      s.addEventListener("change", async (a) => {
        const c = a.target.dataset.itemId, i = a.target.value;
        await h.updateInventory(this.actor, (l) => {
          const d = l.items.find((u) => u.id === c);
          return d && (d.zone = i), l;
        }), this.render();
      });
    }), n.querySelectorAll(".item-notes-input").forEach((s) => {
      s.addEventListener("change", async (a) => {
        const c = a.target.dataset.itemId, i = a.target.value;
        await h.updateInventory(this.actor, (l) => {
          const d = l.items.find((u) => u.id === c);
          return d && (d.notes = i), l;
        });
      });
    }), n.querySelectorAll(".coin-input").forEach((s) => {
      s.addEventListener("change", async (a) => {
        const c = a.target.dataset.currency, i = Math.max(0, parseInt(a.target.value, 10) || 0);
        await h.updateInventory(this.actor, (l) => (l.coins[c] = i, l)), this.render();
      });
    });
  }
  // ─── Action Handlers ──────────────────────────────────────────────────────
  static async _onIncrementQty(o, t) {
    const n = t.dataset.itemId;
    await h.updateInventory(this.actor, (s) => {
      const a = s.items.find((c) => c.id === n);
      return a && (a.quantity = Math.max(1, a.quantity + 1)), s;
    }), this.render();
  }
  static async _onDecrementQty(o, t) {
    const n = t.dataset.itemId;
    await h.updateInventory(this.actor, (s) => {
      const a = s.items.find((c) => c.id === n);
      return a && (a.quantity = Math.max(1, a.quantity - 1)), s;
    }), this.render();
  }
  static async _onDeleteItem(o, t) {
    const n = t.dataset.itemId;
    await Dialog.confirm({
      title: "Remove Item",
      content: "<p>Remove this item from inventory?</p>"
    }) && (await h.updateInventory(this.actor, (a) => (a.items = a.items.filter((c) => c.id !== n), a)), this.render());
  }
  static async _onToggleSecret(o, t) {
    const n = t.dataset.itemId;
    await h.updateInventory(this.actor, (s) => {
      const a = s.items.find((c) => c.id === n);
      return a && (a.isSecret = !a.isSecret), s;
    }), this.render();
  }
  static _onAddItem(o, t) {
    const n = t.dataset.zone ?? "equipped";
    new ee(this.actor, n, () => this.render()).render(!0);
  }
  static _onGiveItem(o, t) {
    const n = t.dataset.itemId;
    new te(this.actor, n, () => this.render()).render(!0);
  }
  static _onGiveCoins() {
    new oe(this.actor, () => this.render()).render(!0);
  }
  static _onGrantCoins() {
    new ne(this.actor, () => this.render()).render(!0);
  }
  static _onOpenShop() {
    var t, n;
    const o = (n = (t = foundry.applications) == null ? void 0 : t.instances) == null ? void 0 : n.get("dolmenwood-shop");
    o ? o.render({ force: !0 }) : new O().render(!0);
  }
};
S(I, "DEFAULT_OPTIONS", {
  id: "dolmenwood-player-inventory",
  window: {
    title: "Inventory",
    resizable: !0
  },
  position: {
    width: 520,
    height: 700
  },
  classes: ["dolmenwood-party-inventory", "player-inventory"],
  actions: {
    addItem: I._onAddItem,
    deleteItem: I._onDeleteItem,
    toggleSecret: I._onToggleSecret,
    giveItem: I._onGiveItem,
    giveCoins: I._onGiveCoins,
    grantCoins: I._onGrantCoins,
    openShop: I._onOpenShop,
    incrementQty: I._onIncrementQty,
    decrementQty: I._onDecrementQty
  }
}), S(I, "PARTS", {
  content: {
    template: B.PLAYER_INVENTORY
  }
});
let P = I;
class ee extends Dialog {
  constructor(o, t, n) {
    const s = M.getAllDefinitions(), a = {};
    for (const i of s)
      a[i.category] || (a[i.category] = ""), a[i.category] += `<option value="${i.id}">${i.name} (${i.size}, ${i.cost.amount} ${i.cost.currency})</option>`;
    let c = "";
    for (const [i, l] of Object.entries(a))
      c += `<optgroup label="${i}">${l}</optgroup>`;
    super({
      title: "Add Item to Inventory",
      content: `
        <form>
          <div class="form-group">
            <label>Item</label>
            <select id="add-item-select">${c}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="add-item-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="add-item-zone">
              <option value="equipped" ${t === "equipped" ? "selected" : ""}>Equipped</option>
              <option value="stowed" ${t === "stowed" ? "selected" : ""}>Stowed</option>
              <option value="tiny" ${t === "tiny" ? "selected" : ""}>Tiny</option>
            </select>
          </div>
          <hr/>
          <details>
            <summary>Add Custom Item Instead</summary>
            <div class="form-group">
              <label>Custom Name</label>
              <input type="text" id="add-custom-name" placeholder="Custom item name" />
            </div>
            <div class="form-group">
              <label>Custom Size</label>
              <select id="add-custom-size">
                <option value="tiny">Tiny (0 slots)</option>
                <option value="normal" selected>Normal (1 slot)</option>
                <option value="large">Large (2 slots)</option>
              </select>
            </div>
          </details>
        </form>
      `,
      buttons: {
        add: {
          label: "Add",
          callback: async (i) => {
            const l = i.find("#add-custom-name").val().trim(), d = Math.max(1, parseInt(i.find("#add-item-qty").val(), 10) || 1), u = i.find("#add-item-zone").val();
            if (l) {
              const f = i.find("#add-custom-size").val();
              await h.updateInventory(o, (g) => (g.items.push({
                id: foundry.utils.randomID(),
                definitionId: "",
                name: l,
                quantity: d,
                zone: u,
                isSecret: !1,
                notes: "",
                customDefinition: { size: f, isCustom: !0 }
              }), g));
            } else {
              const f = i.find("#add-item-select").val(), g = M.getDefinition(f);
              if (!g) return;
              await h.updateInventory(o, (y) => (y.items.push({
                id: foundry.utils.randomID(),
                definitionId: f,
                name: g.name,
                quantity: d,
                zone: u,
                isSecret: !1,
                notes: ""
              }), y));
            }
            n();
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    });
    S(this, "actor");
    S(this, "zone");
    S(this, "onComplete");
    this.actor = o, this.zone = t, this.onComplete = n;
  }
}
class te extends Dialog {
  constructor(e, o, t) {
    var l;
    const n = game, a = (((l = n.actors) == null ? void 0 : l.contents) ?? []).filter(
      (d) => {
        var u;
        return d.id !== e.id && (((u = n.users) == null ? void 0 : u.contents) ?? []).some((f) => !f.isGM && d.testUserPermission(f, "OWNER"));
      }
    ).map((d) => `<option value="${d.id}">${d.name}</option>`).join(""), i = h.getInventory(e).items.find((d) => d.id === o);
    i && super({
      title: `Give ${i.name}`,
      content: `
        <form>
          <div class="form-group">
            <label>Give to</label>
            <select id="give-item-target">${a}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="give-item-qty" value="1" min="1" max="${i.quantity}" />
          </div>
        </form>
      `,
      buttons: {
        give: {
          label: "Give",
          callback: async (d) => {
            var y;
            const u = d.find("#give-item-target").val(), f = Math.min(
              i.quantity,
              Math.max(1, parseInt(d.find("#give-item-qty").val(), 10) || 1)
            );
            (y = n.actors) != null && y.get(u) && (await h.updateInventory(e, (b) => {
              const w = b.items.find((m) => m.id === o);
              return w && (w.quantity -= f, w.quantity <= 0 && (b.items = b.items.filter((m) => m.id !== o))), b;
            }), C.emit(q.GM_GRANT, {
              actorId: u,
              item: {
                definitionId: i.definitionId,
                name: i.name,
                quantity: f,
                zone: i.zone,
                isSecret: !1,
                notes: "",
                customDefinition: i.customDefinition
              }
            }), t());
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "give"
    });
  }
}
class oe extends Dialog {
  constructor(e, o) {
    var c;
    const t = game, n = (((c = t.actors) == null ? void 0 : c.contents) ?? []).filter(
      (i) => {
        var l;
        return i.id !== e.id && (((l = t.users) == null ? void 0 : l.contents) ?? []).some((d) => !d.isGM && i.testUserPermission(d, "OWNER"));
      }
    );
    if (n.length === 0) {
      super({
        title: "Give Coins",
        content: "<p>No other party members to give coins to.</p>",
        buttons: { ok: { label: "OK" } },
        default: "ok"
      });
      return;
    }
    const s = n.map((i) => `<option value="${i.id}">${i.name}</option>`).join(""), a = h.getInventory(e);
    super({
      title: "Give Coins",
      content: `
        <form>
          <div class="form-group">
            <label>Give to</label>
            <select id="give-coins-target">${s}</select>
          </div>
          <div class="form-group">
            <label>PP (have: ${a.coins.pp})</label>
            <input type="number" id="give-pp" value="0" min="0" max="${a.coins.pp}" />
          </div>
          <div class="form-group">
            <label>GP (have: ${a.coins.gp})</label>
            <input type="number" id="give-gp" value="0" min="0" max="${a.coins.gp}" />
          </div>
          <div class="form-group">
            <label>SP (have: ${a.coins.sp})</label>
            <input type="number" id="give-sp" value="0" min="0" max="${a.coins.sp}" />
          </div>
          <div class="form-group">
            <label>CP (have: ${a.coins.cp})</label>
            <input type="number" id="give-cp" value="0" min="0" max="${a.coins.cp}" />
          </div>
        </form>
      `,
      buttons: {
        give: {
          label: "Give",
          callback: (i) => {
            const l = i.find("#give-coins-target").val(), d = Math.min(a.coins.pp, Math.max(0, parseInt(i.find("#give-pp").val(), 10) || 0)), u = Math.min(a.coins.gp, Math.max(0, parseInt(i.find("#give-gp").val(), 10) || 0)), f = Math.min(a.coins.sp, Math.max(0, parseInt(i.find("#give-sp").val(), 10) || 0)), g = Math.min(a.coins.cp, Math.max(0, parseInt(i.find("#give-cp").val(), 10) || 0));
            d + u + f + g !== 0 && (C.emit(q.GIVE_COINS, {
              fromActorId: e.id,
              toActorId: l,
              cp: g,
              sp: f,
              gp: u,
              pp: d
            }), o());
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "give"
    });
  }
}
class ne extends Dialog {
  constructor(e, o) {
    super({
      title: `Grant Coins to ${e.name}`,
      content: `
        <form>
          <div class="form-group">
            <label>PP</label>
            <input type="number" id="grant-pp" value="0" min="0" />
          </div>
          <div class="form-group">
            <label>GP</label>
            <input type="number" id="grant-gp" value="0" min="0" />
          </div>
          <div class="form-group">
            <label>SP</label>
            <input type="number" id="grant-sp" value="0" min="0" />
          </div>
          <div class="form-group">
            <label>CP</label>
            <input type="number" id="grant-cp" value="0" min="0" />
          </div>
        </form>
      `,
      buttons: {
        grant: {
          label: "Grant",
          callback: async (t) => {
            var i;
            const n = Math.max(0, parseInt(t.find("#grant-pp").val(), 10) || 0), s = Math.max(0, parseInt(t.find("#grant-gp").val(), 10) || 0), a = Math.max(0, parseInt(t.find("#grant-sp").val(), 10) || 0), c = Math.max(0, parseInt(t.find("#grant-cp").val(), 10) || 0);
            n + s + a + c !== 0 && (await h.updateInventory(e, (l) => (l.coins.pp += n, l.coins.gp += s, l.coins.sp += a, l.coins.cp += c, l)), (i = ui.notifications) == null || i.info(`Granted coins to ${e.name}.`), o());
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "grant"
    });
  }
}
function F(r, e, o, t) {
  const n = t ?? { pp: 0, gp: 0, sp: 0, cp: 0 };
  if (!t)
    for (const g of r) {
      const y = h.getInventory(g);
      n.pp += y.coins.pp, n.gp += y.coins.gp, n.sp += y.coins.sp, n.cp += y.coins.cp;
    }
  const s = [];
  for (const g of r) {
    const y = h.getInventory(g), b = o !== null && !o.isGM && g.testUserPermission(o, "OWNER");
    for (const w of y.items) {
      if (w.isSecret && !e && !b) continue;
      const m = M.getDefinition(w.definitionId);
      s.push({
        name: w.name,
        quantity: w.quantity,
        category: (m == null ? void 0 : m.category) ?? "Custom",
        ownerName: g.name ?? "Unknown",
        isSecret: w.isSecret
      });
    }
  }
  const a = {};
  for (const g of [...s].sort((y, b) => y.name.localeCompare(b.name)))
    a[g.category] || (a[g.category] = []), a[g.category].push(g);
  const c = n.cp + n.sp * 10 + n.gp * 100 + n.pp * 500, i = Math.floor(c / 100), l = Math.floor(c % 100 / 10), d = c % 10, u = [];
  i && u.push(`${i} gp`), l && u.push(`${l} sp`), (d || u.length === 0) && u.push(`${d} cp`);
  const f = u.join(" ");
  return {
    grouped: a,
    coins: n,
    totalCp: c,
    totalGpStr: f,
    hasItems: s.length > 0
  };
}
const E = class E extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  async _prepareContext(e) {
    var l, d;
    const o = game, t = (((l = o.actors) == null ? void 0 : l.contents) ?? []).filter(
      (u) => {
        var f;
        return (((f = o.users) == null ? void 0 : f.contents) ?? []).some((g) => !g.isGM && u.testUserPermission(g, "OWNER"));
      }
    ), n = t.map((u) => {
      const f = h.getInventory(u), g = L(f, M.getMap()), y = {};
      for (const b of f.items)
        y[b.zone] || (y[b.zone] = []);
      return {
        actor: u,
        actorId: u.id,
        inventory: f,
        encumbrance: g,
        isOwner: u.isOwner
      };
    }).filter(Boolean), s = { cp: 0, sp: 0, gp: 0, pp: 0 };
    for (const u of n)
      u && (s.cp += u.inventory.coins.cp, s.sp += u.inventory.coins.sp, s.gp += u.inventory.coins.gp, s.pp += u.inventory.coins.pp);
    const a = ((d = o.user) == null ? void 0 : d.isGM) ?? !1, c = o.user ?? null, i = F(t, a, c, s);
    return {
      members: n,
      partyTotals: s,
      partySummary: i,
      isGM: a,
      transactions: h.getTransactions().slice(-20).reverse()
    };
  }
  _onRender(e, o) {
    this.element.querySelectorAll(".player-column[data-actor-id]").forEach((t) => {
      t.addEventListener("click", (n) => {
        var c;
        if (n.target.closest("button")) return;
        const s = t.dataset.actorId, a = (c = game.actors) == null ? void 0 : c.get(s);
        a && new P(a).render(!0);
      });
    });
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static _onOpenShop() {
    new O().render(!0);
  }
  static _onOpenPlayerInventory(e, o) {
    var s;
    const t = o.dataset.actorId, n = (s = game.actors) == null ? void 0 : s.get(t);
    n && new P(n).render(!0);
  }
};
S(E, "DEFAULT_OPTIONS", {
  id: "dolmenwood-party-overview",
  window: {
    title: "Party Inventory Overview",
    resizable: !0
  },
  position: {
    width: 960,
    height: 620
  },
  classes: ["dolmenwood-party-inventory", "party-overview"],
  actions: {
    openShop: E._onOpenShop,
    openPlayerInventory: E._onOpenPlayerInventory
  }
}), S(E, "PARTS", {
  content: {
    template: B.PARTY_OVERVIEW
  }
});
let _ = E;
Hooks.once("init", () => {
  console.log(`${v} | Initializing`), game.settings.register(v, x.SHOP_STATE, {
    name: "Shop State",
    hint: "Active tags and available items for the shop panel.",
    scope: "world",
    config: !1,
    type: Object,
    default: { activeTags: [], availableItems: [] }
  }), game.settings.register(v, R.TRANSACTION_LOG, {
    name: "Transaction Log",
    scope: "world",
    config: !1,
    type: Array,
    default: []
  }), K();
});
Hooks.once("ready", async () => {
  var o, t;
  console.log(`${v} | Ready`), await J(), C.initialize();
  const r = game.modules.get(v);
  r && (r.api = {
    openPartyOverview: () => U(),
    openPlayerInventory: (n) => N(n),
    openShop: () => se()
  });
  const e = game;
  !((o = e.user) != null && o.isGM) && ((t = e.user) != null && t.character) && N(e.user.character);
});
Hooks.on("updateActor", (r, e) => {
  var n, s, a, c;
  if (!((n = e.flags) == null ? void 0 : n[v])) return;
  const t = (s = foundry.applications) == null ? void 0 : s.instances;
  if (t)
    for (const i of t.values()) {
      const l = i.id ?? "";
      if (l === "dolmenwood-party-overview")
        (a = i.render) == null || a.call(i);
      else if (l === "dolmenwood-player-inventory") {
        const d = i;
        ((c = d.actor) == null ? void 0 : c.id) === r.id && d.render();
      }
    }
});
Hooks.on("getSceneControlButtons", (r) => {
  var n;
  const o = ((n = game.user) == null ? void 0 : n.isGM) ?? !1, t = r.tokens;
  t && (t.tools["dolmenwood-party-inventory"] = {
    name: "dolmenwood-party-inventory",
    title: o ? "Party Inventory" : "My Inventory",
    icon: "fas fa-backpack",
    order: Object.keys(t.tools).length,
    button: !0,
    onChange: o ? () => U() : () => N()
  });
});
function U() {
  var o, t;
  if (!((o = game.user) != null && o.isGM)) {
    (t = ui.notifications) == null || t.warn("Only the GM can access the Party Overview.");
    return;
  }
  const e = D("dolmenwood-party-overview");
  e ? e.render({ force: !0 }) : new _().render(!0);
}
function N(r) {
  var n, s, a;
  const e = game;
  let o;
  if (typeof r == "string" ? o = (n = e.actors) == null ? void 0 : n.get(r) : r instanceof Actor ? o = r : o = ((s = e.user) == null ? void 0 : s.character) ?? void 0, !o) {
    (a = ui.notifications) == null || a.warn("No actor found. Assign a character to your user first.");
    return;
  }
  const t = D("dolmenwood-player-inventory");
  t ? t.render({ force: !0 }) : new P(o).render(!0);
}
function se() {
  const r = D("dolmenwood-shop");
  r ? r.render({ force: !0 }) : new O().render(!0);
}
function D(r) {
  var o;
  const e = (o = foundry.applications) == null ? void 0 : o.instances;
  if (e) {
    for (const t of e.values())
      if (t.id === r)
        return t;
  }
}
//# sourceMappingURL=module.js.map
