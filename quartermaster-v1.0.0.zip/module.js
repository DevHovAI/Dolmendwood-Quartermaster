var Q = Object.defineProperty;
var V = (r, e, t) => e in r ? Q(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var b = (r, e, t) => V(r, typeof e != "symbol" ? e + "" : e, t);
const g = "dolmenwood-party-inventory", k = {
  INVENTORY: "inventory",
  TRANSACTION_LOG: "transactionLog"
}, P = {
  PARTY_OVERVIEW: `modules/${g}/templates/party-overview.hbs`,
  PLAYER_INVENTORY: `modules/${g}/templates/player-inventory.hbs`,
  SHOP: `modules/${g}/templates/shop.hbs`,
  PARTIALS: {
    INVENTORY_ZONE: `modules/${g}/templates/partials/inventory-zone.hbs`,
    ITEM_ROW: `modules/${g}/templates/partials/item-row.hbs`,
    COIN_DISPLAY: `modules/${g}/templates/partials/coin-display.hbs`,
    ENCUMBRANCE_BAR: `modules/${g}/templates/partials/encumbrance-bar.hbs`,
    TRANSACTION_LOG: `modules/${g}/templates/partials/transaction-log.hbs`
  }
}, I = {
  PURCHASE_ITEM: "purchaseItem",
  GM_GRANT: "gmGrant",
  GM_REMOVE: "gmRemove",
  REQUEST_REFRESH: "requestRefresh"
}, E = {
  PARTY_ACTOR_IDS: "partyActorIds",
  SHOP_STATE: "shopState"
}, L = `module.${g}`, U = [
  [0, 3, 40],
  [4, 5, 30],
  [6, 7, 20],
  [8, 10, 10]
], Y = [
  [0, 10, 40],
  [11, 12, 30],
  [13, 14, 20],
  [15, 16, 10]
];
function $(r, e) {
  for (const [t, a, o] of e)
    if (r >= t && r <= a) return o;
  return 10;
}
function H(r, e) {
  var w;
  let t = 0, a = 0, o = 0;
  for (const B of r.items) {
    const x = e.get(B.definitionId), M = ((w = B.customDefinition) == null ? void 0 : w.size) ?? (x == null ? void 0 : x.size) ?? "normal", G = B.quantity;
    B.zone === "tiny" ? o += G : B.zone === "equipped" ? M === "tiny" || (M === "normal" ? t += G : M === "large" && (t += G * 2)) : B.zone === "stowed" && (M === "tiny" ? o += G : M === "normal" ? a += G : M === "large" && (a += G * 2));
  }
  const n = Math.max(0, 10 - o), i = Math.max(0, o - 10);
  a += Math.ceil(i / 10);
  const { cp: s, sp: c, gp: l, pp: d } = r.coins, m = s + c * 10 + l * 100 + d * 500, h = Math.floor(m / 100);
  a += h;
  const f = $(t, U), u = $(a, Y), y = Math.min(f, u);
  let C = "none";
  return f < u ? C = "equipped" : u < f ? C = "stowed" : y < 40 && (C = "both"), {
    equippedSlots: t,
    stowedSlots: a,
    equippedSpeed: f,
    stowedSpeed: u,
    finalSpeed: y,
    bottleneck: C,
    tinyCount: o,
    freeTinySlots: n,
    tinyOverflow: i,
    coinSlots: h
  };
}
function j(r) {
  switch (r) {
    case 40:
      return "speed-green";
    case 30:
      return "speed-yellow";
    case 20:
      return "speed-orange";
    case 10:
      return "speed-red";
  }
}
function Z() {
  Handlebars.registerHelper("eq", (r, e) => r === e), Handlebars.registerHelper("neq", (r, e) => r !== e), Handlebars.registerHelper("gt", (r, e) => r > e), Handlebars.registerHelper("lt", (r, e) => r < e), Handlebars.registerHelper(
    "formatCost",
    (r, e) => `${r} ${e}`
  ), Handlebars.registerHelper(
    "speedColor",
    (r) => j(r)
  ), Handlebars.registerHelper(
    "equippedBarWidth",
    (r) => Math.min(100, r / 10 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper(
    "stowedBarWidth",
    (r) => Math.min(100, r / 16 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper("bottleneckLabel", (r) => {
    switch (r) {
      case "equipped":
        return "Equipped";
      case "stowed":
        return "Stowed";
      case "both":
        return "Both";
      default:
        return "";
    }
  }), Handlebars.registerHelper(
    "coinTotal",
    (r, e, t, a) => {
      const o = [];
      return a > 0 && o.push(`${a} pp`), t > 0 && o.push(`${t} gp`), e > 0 && o.push(`${e} sp`), r > 0 && o.push(`${r} cp`), o.length > 0 ? o.join(", ") : "0 gp";
    }
  ), Handlebars.registerHelper("sizeLabel", (r) => {
    switch (r) {
      case "tiny":
        return "Tiny";
      case "normal":
        return "Normal";
      case "large":
        return "Large";
      default:
        return r;
    }
  }), Handlebars.registerHelper("slotCost", (r) => {
    switch (r) {
      case "tiny":
        return "0 slots";
      case "normal":
        return "1 slot";
      case "large":
        return "2 slots";
      default:
        return "-";
    }
  });
}
async function K() {
  const r = Object.values(P.PARTIALS);
  await loadTemplates(r);
}
function J(r) {
  return {
    actorId: r,
    coins: { cp: 0, sp: 0, gp: 0, pp: 0 },
    items: []
  };
}
class p {
  static getInventory(e) {
    return e.getFlag(g, k.INVENTORY) ?? J(e.id ?? "");
  }
  static async setInventory(e, t) {
    await e.setFlag(g, k.INVENTORY, t);
  }
  static async updateInventory(e, t) {
    const a = this.getInventory(e), o = t(structuredClone(a));
    await this.setInventory(e, o);
  }
  static getTransactions() {
    return game.settings.get(g, k.TRANSACTION_LOG) ?? [];
  }
  static async appendTransaction(e) {
    const t = this.getTransactions();
    t.push(e);
    const a = t.slice(-200);
    await game.settings.set(g, k.TRANSACTION_LOG, a);
  }
}
class v {
  static initialize() {
    game.socket.on(
      L,
      (e) => v.handleIncoming(e)
    );
  }
  /**
   * Emit a socket event to all clients (including ourselves, handled locally too).
   */
  static emit(e, t) {
    const a = {
      event: e,
      data: t,
      userId: game.user.id
    };
    game.socket.emit(L, a);
  }
  static handleIncoming(e) {
    var a, o, n;
    const t = game;
    switch (e.event) {
      case I.GM_GRANT:
        (a = t.user) != null && a.isGM && v.onGMGrant(e.data);
        break;
      case I.GM_REMOVE:
        (o = t.user) != null && o.isGM && v.onGMRemove(e.data);
        break;
      case I.PURCHASE_ITEM:
        (n = t.user) != null && n.isGM && v.onPurchase(e.data);
        break;
      case I.REQUEST_REFRESH:
        v.onRequestRefresh();
        break;
    }
  }
  static async onGMGrant(e) {
    var n;
    const t = (n = game.actors) == null ? void 0 : n.get(e.actorId);
    if (!t) return;
    const a = {
      ...e.item,
      id: foundry.utils.randomID()
    };
    await p.updateInventory(t, (i) => (i.items.push(a), i));
    const o = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "gm_grant",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: a.definitionId, name: a.name, quantity: a.quantity }],
      coinsDelta: []
    };
    await p.appendTransaction(o), v.emit(I.REQUEST_REFRESH, {});
  }
  static async onGMRemove(e) {
    var o;
    const t = (o = game.actors) == null ? void 0 : o.get(e.actorId);
    if (!t) return;
    let a;
    if (await p.updateInventory(t, (n) => {
      const i = n.items.findIndex((s) => s.id === e.itemId);
      if (i !== -1) {
        const [s] = n.items.splice(i, 1);
        a = { definitionId: s.definitionId, name: s.name, quantity: s.quantity };
      }
      return n;
    }), a) {
      const n = {
        id: foundry.utils.randomID(),
        timestamp: Date.now(),
        type: "gm_remove",
        fromActorId: e.actorId,
        toActorId: "shop",
        items: [a],
        coinsDelta: []
      };
      await p.appendTransaction(n);
    }
    v.emit(I.REQUEST_REFRESH, {});
  }
  static async onPurchase(e) {
    var o;
    const t = (o = game.actors) == null ? void 0 : o.get(e.actorId);
    if (!t) return;
    await p.updateInventory(t, (n) => {
      const i = (e.totalCost.cp ?? 0) + (e.totalCost.sp ?? 0) * 10 + (e.totalCost.gp ?? 0) * 100 + (e.totalCost.pp ?? 0) * 500, s = n.coins.cp + n.coins.sp * 10 + n.coins.gp * 100 + n.coins.pp * 500;
      if (s < i) return n;
      const c = s - i;
      return n.coins.pp = 0, n.coins.gp = Math.floor(c / 100), n.coins.sp = Math.floor(c % 100 / 10), n.coins.cp = c % 10, n.items.push({
        id: foundry.utils.randomID(),
        definitionId: e.definitionId,
        name: e.definitionId,
        // will be resolved by UI from catalog
        quantity: e.quantity,
        zone: e.zone,
        isSecret: !1,
        notes: ""
      }), n;
    });
    const a = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "purchase",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: e.definitionId, name: e.definitionId, quantity: e.quantity }],
      coinsDelta: [
        {
          actorId: e.actorId,
          cp: -e.totalCost.cp,
          sp: -e.totalCost.sp,
          gp: -e.totalCost.gp,
          pp: -e.totalCost.pp
        }
      ]
    };
    await p.appendTransaction(a), v.emit(I.REQUEST_REFRESH, {});
  }
  static onRequestRefresh() {
    var e, t;
    for (const a of Object.values(((e = foundry.applications) == null ? void 0 : e.instances) ?? {}))
      (a.id ?? "").startsWith("dolmenwood-") && ((t = a.render) == null || t.call(a));
  }
}
const A = [
  // ─── ARMOUR ───────────────────────────────────────────────────────────────
  {
    id: "unarmoured",
    name: "Unarmoured",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "gp" },
    weight: 0,
    description: "No armour. AC 10.",
    qualities: ["AC 10"],
    tags: [],
    isCustom: !1
  },
  {
    id: "leather-armour",
    name: "Leather Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 200,
    description: "Light armour made of hardened leather. AC 12.",
    qualities: ["AC 12"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bark-armour",
    name: "Bark Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 300,
    description: "Armour crafted from treated tree bark. AC 13.",
    qualities: ["AC 13"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chainmail",
    name: "Chainmail",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 400,
    description: "Interlocking metal rings. AC 14.",
    qualities: ["AC 14"],
    tags: [],
    isCustom: !1
  },
  {
    id: "pinecone-armour",
    name: "Pinecone Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 400,
    description: "Armour fashioned from overlapping pinecone scales. AC 15.",
    qualities: ["AC 15"],
    tags: [],
    isCustom: !1
  },
  {
    id: "plate-mail",
    name: "Plate Mail",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 60, currency: "gp" },
    weight: 500,
    description: "Heavy plate armour. AC 16.",
    qualities: ["AC 16"],
    tags: [],
    isCustom: !1
  },
  {
    id: "full-plate",
    name: "Full Plate",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1e3, currency: "gp" },
    weight: 700,
    description: "The finest and heaviest plate armour. AC 17.",
    qualities: ["AC 17"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shield",
    name: "Shield",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A wooden or metal shield. AC +1.",
    qualities: ["AC +1"],
    tags: [],
    isCustom: !1
  },
  // ─── WEAPONS ──────────────────────────────────────────────────────────────
  {
    id: "battle-axe",
    name: "Battle Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 100,
    description: "A heavy two-handed axe. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "club",
    name: "Club",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 20,
    description: "A heavy wooden club. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "crossbow",
    name: "Crossbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 50,
    description: "A mechanical ranged weapon. 1d8 damage.",
    qualities: ["1d8", "Missile (80/160/240)", "Reload", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "dagger",
    name: "Dagger",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "A short blade useful in melee and as a thrown weapon. 1d4 damage.",
    qualities: ["Melee", "1d4", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "hand-axe",
    name: "Hand Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 20,
    description: "A small axe, usable in melee or thrown. 1d6 damage.",
    qualities: ["Melee", "1d6", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial",
    name: "Holy Water (Vial)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "Blessed water, effective against undead when thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "lance",
    name: "Lance",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !0,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 100,
    description: "A long cavalry weapon. 1d6 damage. Cannot be stowed.",
    qualities: ["Brace", "Charge", "Melee", "1d6", "Reach"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longbow",
    name: "Longbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 40,
    description: "A tall war bow with long range. 1d8 damage.",
    qualities: ["1d8", "Missile (70/140/210)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longsword",
    name: "Longsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "A versatile one-handed sword. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "mace",
    name: "Mace",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy-headed bludgeoning weapon. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask-burning",
    name: "Oil Flask (Burning)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of oil set alight and thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "polearm",
    name: "Polearm",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 140,
    description: "A long hafted weapon with a blade or head. 1d10 damage.",
    qualities: ["Brace", "Melee", "1d10", "Reach", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortbow",
    name: "Shortbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A compact bow for skirmishing. 1d6 damage.",
    qualities: ["1d6", "Missile (50/100/150)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortsword",
    name: "Shortsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 20,
    description: "A short, light blade. 1d6 damage.",
    qualities: ["Melee", "1d6"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling",
    name: "Sling",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 10,
    description: "A simple ranged weapon using stones. 1d4 damage.",
    qualities: ["1d4", "Missile (40/80/160)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "spear",
    name: "Spear",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 30,
    description: "A thrusting weapon, useful in melee and as a thrown weapon. 1d6 damage.",
    qualities: ["Brace", "Melee", "1d6", "Missile (20/40/60)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "staff",
    name: "Staff",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 40,
    description: "A long wooden staff. 1d6 damage.",
    qualities: ["Melee", "1d6", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "torch-flaming",
    name: "Torch (Flaming)",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 15,
    description: "A lit torch used as an improvised weapon. 1d4 damage. Sold in sets of 3.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "two-handed-sword",
    name: "Two-Handed Sword",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 140,
    description: "A massive greatsword requiring both hands. 1d10 damage.",
    qualities: ["Melee", "1d10", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "war-hammer",
    name: "War Hammer",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy hammer for smashing armour. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  // ─── AMMUNITION ───────────────────────────────────────────────────────────
  {
    id: "arrows-quiver",
    name: "Arrows (Quiver of 20)",
    category: "Ammunition",
    subcategory: "Arrows",
    size: "normal",
    cannotBeStowed: !1,
    unit: "quiver",
    cost: { amount: 5, currency: "cp" },
    weight: 20,
    description: "A quiver of 20 arrows for use with bows.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quarrels-case",
    name: "Quarrels (Case of 20)",
    category: "Ammunition",
    subcategory: "Quarrels",
    size: "normal",
    cannotBeStowed: !1,
    unit: "case",
    cost: { amount: 10, currency: "cp" },
    weight: 20,
    description: "A case of 20 crossbow quarrels.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling-stones",
    name: "Sling Stones",
    category: "Ammunition",
    subcategory: "Stones",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "cp" },
    weight: 1,
    description: "Smooth stones for use with a sling. Free to acquire.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CONTAINERS ────────────────────────────────────────
  {
    id: "backpack",
    name: "Backpack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A sturdy canvas backpack. Capacity: 400 coins.",
    qualities: ["Capacity: 400 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "barrel",
    name: "Barrel",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 70,
    description: "A wooden barrel. Capacity: 320 pints.",
    qualities: ["Capacity: 320 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "belt-pouch",
    name: "Belt Pouch",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A small leather pouch worn on the belt. Capacity: 50 coins.",
    qualities: ["Capacity: 50 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bucket",
    name: "Bucket",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "A wooden or metal bucket. Capacity: 40 pints.",
    qualities: ["Capacity: 40 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-large",
    name: "Casket (Iron, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 400,
    description: "A large iron strongbox. Capacity: 800 coins.",
    qualities: ["Capacity: 800 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-small",
    name: "Casket (Iron, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A small iron strongbox. Capacity: 250 coins.",
    qualities: ["Capacity: 250 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-large",
    name: "Chest (Wooden, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 200,
    description: "A large wooden chest. Capacity: 1000 coins.",
    qualities: ["Capacity: 1000 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-small",
    name: "Chest (Wooden, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A small wooden chest. Capacity: 300 coins.",
    qualities: ["Capacity: 300 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sack",
    name: "Sack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A large cloth sack. Capacity: 600 coins.",
    qualities: ["Capacity: 600 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "scroll-case",
    name: "Scroll Case",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A protective tube for scrolls and maps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "vial-glass",
    name: "Vial (Glass)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small glass vial. Capacity: 0.5 pint.",
    qualities: ["Capacity: 0.5 pint"],
    tags: [],
    isCustom: !1
  },
  {
    id: "waterskin",
    name: "Waterskin",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A leather flask for carrying water. Capacity: 2 pints.",
    qualities: ["Capacity: 2 pints"],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — LIGHT ─────────────────────────────────────────────
  {
    id: "candles-10",
    name: "Candles (10)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Ten tallow candles, providing dim light for 1 hour each.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-hooded",
    name: "Lantern (Hooded)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 20,
    description: "A lantern with adjustable hood to control light.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-bullseye",
    name: "Lantern (Bullseye)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 20,
    description: "A lantern that focuses light in a cone.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask",
    name: "Oil (Flask)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of lamp oil, fueling a lantern for 4 hours.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tinder-box",
    name: "Tinder Box",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "Steel, flint, and tinder for starting fires.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "torches-3",
    name: "Torches (3)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Three wooden torches, each burning for 1 hour.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CAMPING AND TRAVEL ────────────────────────────────
  {
    id: "bedroll",
    name: "Bedroll",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 70,
    description: "A rolled sleeping mat and blanket.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "cooking-pots",
    name: "Cooking Pots",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 100,
    description: "A set of iron cooking pots for camp meals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "firewood-bundle",
    name: "Firewood (Bundle, 8 hours)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 200,
    description: "A bundle of firewood sufficient for 8 hours of burning.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "fishing-rod-and-tackle",
    name: "Fishing Rod and Tackle",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A rod, line, and hook for fishing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-preserved",
    name: "Rations (Preserved, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Hard tack, jerky, and dried goods lasting one day.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-fresh",
    name: "Rations (Fresh, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Fresh food for one day — must be consumed within a few days.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tent",
    name: "Tent",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "A canvas tent sheltering up to two people.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — HOLY ITEMS ────────────────────────────────────────
  {
    id: "holy-symbol-gold",
    name: "Holy Symbol (Gold)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 20,
    description: "A golden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-silver",
    name: "Holy Symbol (Silver)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A silver holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-wooden",
    name: "Holy Symbol (Wooden)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A carved wooden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial-gear",
    name: "Holy Water (Vial)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "A vial of blessed water, effective against undead.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — MISCELLANEOUS TOOLS ───────────────────────────────
  {
    id: "bell-miniature",
    name: "Bell (Miniature)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A small bell useful for alarms and signals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "block-and-tackle",
    name: "Block and Tackle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "A pulley system for hoisting heavy loads.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "caltrops-bag",
    name: "Caltrops (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Metal spikes scattered to slow pursuit.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chain-10ft",
    name: "Chain (10' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 100,
    description: "Ten feet of iron chain.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chalk-10-sticks",
    name: "Chalk (10 Sticks)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "Ten sticks of chalk for marking walls and floors.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chisel",
    name: "Chisel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A metal chisel for cutting stone and wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "crowbar",
    name: "Crowbar",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "An iron pry bar for forcing doors and shifting stones.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "grappling-hook",
    name: "Grappling Hook",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "An iron hook for climbing walls and crossing gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-small",
    name: "Hammer (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 15,
    description: "A small hammer for driving spikes and basic carpentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-sledgehammer",
    name: "Hammer (Sledgehammer)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy hammer for breaking rock and forcing barriers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "ink-vial",
    name: "Ink (Vial)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 8, currency: "gp" },
    weight: 5,
    description: "A vial of black writing ink.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "iron-spikes-12",
    name: "Iron Spikes (12)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A dozen iron spikes for pitons, door-spiking, and general use.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lock",
    name: "Lock",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "An iron padlock with key.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "magnifying-glass",
    name: "Magnifying Glass",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 5,
    description: "A glass lens for examining small objects and starting fires in sunlight.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "manacles",
    name: "Manacles",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 30,
    description: "Iron restraints with a lock for binding prisoners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "marbles-bag",
    name: "Marbles (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "Glass marbles scattered to trip pursuers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mining-pick",
    name: "Mining Pick",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy pick for breaking rock.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mirror-small",
    name: "Mirror (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 5,
    description: "A small steel mirror for signalling and peeking around corners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-stringed",
    name: "Musical Instrument (Stringed)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 30,
    description: "A lute, lyre, or similar stringed instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-wind",
    name: "Musical Instrument (Wind)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A flute, recorder, or similar wind instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "paper-parchment-2-sheets",
    name: "Paper or Parchment (2 Sheets)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 2,
    description: "Two sheets of paper or parchment for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "pole-10ft",
    name: "Pole (10' Long Wooden)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "A ten-foot wooden pole for prodding, vaulting, and bridging gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quill",
    name: "Quill",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A feather quill for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-50ft",
    name: "Rope (50' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "Fifty feet of hempen rope.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-ladder-25ft",
    name: "Rope Ladder (25' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 50,
    description: "A twenty-five foot rope ladder.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "saw",
    name: "Saw",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A toothed blade for cutting wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "shovel",
    name: "Shovel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "An iron-headed shovel for digging.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "spell-book-blank",
    name: "Spell Book (Blank)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 30,
    description: "A blank tome for recording spells.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "thieves-tools",
    name: "Thieves' Tools",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 10,
    description: "A set of picks, tension wrenches, and other tools for opening locks.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "twine-100ft",
    name: "Twine (100' Ball)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A ball of one hundred feet of thin twine.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "whistle",
    name: "Whistle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small metal whistle for signalling.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CLOTHING ──────────────────────────────────────────
  {
    id: "clothes-common",
    name: "Clothes (Common)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Plain, practical everyday clothing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-extravagant",
    name: "Clothes (Extravagant)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 60,
    description: "Elaborate clothing in silk and velvet, befitting a noble.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-fine",
    name: "Clothes (Fine)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 40,
    description: "Quality clothing suitable for merchants and minor gentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "habit-friars",
    name: "Habit (Friar's)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "A simple hooded robe worn by friars and mendicants.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "robes-ritual",
    name: "Robes (Ritual)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "Ceremonial robes worn during religious rites.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "winter-cloak",
    name: "Winter Cloak",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A heavy wool cloak for cold weather.",
    qualities: [],
    tags: [],
    isCustom: !1
  }
], N = new Map(
  A.map((r) => [r.id, r])
);
[
  ...new Set(A.map((r) => r.category))
];
[
  ...new Set(A.flatMap((r) => r.tags))
].sort();
class q {
  static getDefinition(e) {
    return N.get(e);
  }
  static getAllDefinitions() {
    return A;
  }
  static getMap() {
    return N;
  }
  static getByCategory(e) {
    return A.filter((t) => t.category === e);
  }
  static getBySubcategory(e) {
    return A.filter((t) => t.subcategory === e);
  }
  /** Returns items that have ALL of the specified tags, plus items with no tags (always visible). */
  static filterByTags(e) {
    return e.length === 0 ? A : A.filter(
      (t) => t.tags.length === 0 || e.every((a) => t.tags.includes(a))
    );
  }
  static getCategories() {
    return [...new Set(A.map((e) => e.category))];
  }
  static getSubcategories(e) {
    const t = e ? A.filter((a) => a.category === e) : A;
    return [...new Set(t.map((a) => a.subcategory))];
  }
  static getAllTags() {
    return [...new Set(A.flatMap((e) => e.tags))].sort();
  }
  /** Group catalog items by category, then subcategory */
  static groupedByCategoryAndSubcategory() {
    const e = {};
    for (const t of A)
      e[t.category] || (e[t.category] = {}), e[t.category][t.subcategory] || (e[t.category][t.subcategory] = []), e[t.category][t.subcategory].push(t);
    return e;
  }
}
const T = class T extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor() {
    super(...arguments);
    /** Currently selected target actor ID */
    b(this, "selectedActorId", null);
    /** Current search/filter text */
    b(this, "searchText", "");
  }
  async _prepareContext(t) {
    var h, f;
    const a = game, o = a.settings.get(g, E.SHOP_STATE), i = a.settings.get(g, "partyActorIds").map((u) => {
      var y;
      return (y = a.actors) == null ? void 0 : y.get(u);
    }).filter((u) => !!u);
    !this.selectedActorId && i.length > 0 && (this.selectedActorId = i[0].id ?? null);
    const s = this.selectedActorId ? (h = a.actors) == null ? void 0 : h.get(this.selectedActorId) : void 0;
    let c = q.filterByTags(o.activeTags);
    if (o.availableItems.length > 0 && (c = c.filter((u) => o.availableItems.includes(u.id))), this.searchText) {
      const u = this.searchText.toLowerCase();
      c = c.filter(
        (y) => y.name.toLowerCase().includes(u) || y.category.toLowerCase().includes(u) || y.subcategory.toLowerCase().includes(u)
      );
    }
    const l = {};
    for (const u of c)
      l[u.category] || (l[u.category] = []), l[u.category].push(u);
    let d, m;
    return s && (d = p.getInventory(s), m = H(
      d,
      q.getMap()
    )), {
      shopState: o,
      allTags: q.getAllTags(),
      grouped: l,
      partyMembers: i,
      selectedActorId: this.selectedActorId,
      selectedActor: s,
      selectedInventory: d,
      selectedEncumbrance: m,
      searchText: this.searchText,
      isGM: ((f = a.user) == null ? void 0 : f.isGM) ?? !1
    };
  }
  _onRender(t, a) {
    var n, i;
    const o = this.element;
    (n = o.querySelector("#shop-target-actor")) == null || n.addEventListener(
      "change",
      (s) => {
        this.selectedActorId = s.target.value || null, this.render();
      }
    ), (i = o.querySelector("#shop-search")) == null || i.addEventListener(
      "input",
      (s) => {
        this.searchText = s.target.value, this.render();
      }
    );
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static async _onToggleTag(t, a) {
    const o = a.dataset.tag, n = game, i = n.settings.get(g, E.SHOP_STATE), s = i.activeTags.indexOf(o);
    s === -1 ? i.activeTags.push(o) : i.activeTags.splice(s, 1), await n.settings.set(g, E.SHOP_STATE, i), this.render();
  }
  static async _onPurchaseItem(t, a) {
    var y, C;
    const o = a.dataset.itemId, n = q.getDefinition(o);
    if (!n || !this.selectedActorId) return;
    const s = (y = game.actors) == null ? void 0 : y.get(this.selectedActorId);
    if (!s) return;
    const c = p.getInventory(s), l = c.coins.cp + c.coins.sp * 10 + c.coins.gp * 100 + c.coins.pp * 500, d = n.cost.currency === "cp" ? n.cost.amount : n.cost.currency === "sp" ? n.cost.amount * 10 : n.cost.currency === "gp" ? n.cost.amount * 100 : n.cost.amount * 500, m = l >= d;
    if (!await new Promise((w) => {
      new Dialog({
        title: "Purchase Item",
        content: `
          <p>Purchase <strong>${n.name}</strong> for <strong>${n.cost.amount} ${n.cost.currency}</strong>?</p>
          <p>Target: <strong>${s.name}</strong></p>
          ${m ? "" : '<p class="warning"><i class="fas fa-exclamation-triangle"></i> Insufficient funds! Proceed anyway (GM override)?</p>'}
          <div class="form-group">
            <label>Add to zone:</label>
            <select id="purchase-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
        `,
        buttons: {
          confirm: {
            label: m ? "Purchase" : "Override & Purchase",
            icon: `<i class="fas ${m ? "fa-shopping-cart" : "fa-exclamation-triangle"}"></i>`,
            callback: () => w(!0)
          },
          cancel: { label: "Cancel", callback: () => w(!1) }
        },
        default: "confirm"
      }).render(!0);
    })) return;
    const f = "stowed", u = m ? l - d : l;
    await p.updateInventory(s, (w) => (m && (w.coins.gp = Math.floor(u / 100), w.coins.sp = Math.floor(u % 100 / 10), w.coins.cp = u % 10, w.coins.pp = 0), w.items.push({
      id: foundry.utils.randomID(),
      definitionId: o,
      name: n.name,
      quantity: 1,
      zone: f,
      isSecret: !1,
      notes: ""
    }), w)), (C = ui.notifications) == null || C.info(`Purchased ${n.name} for ${s.name}.`), this.render();
  }
  static _onGrantItem(t, a) {
    var i, s;
    const o = a.dataset.itemId, n = q.getDefinition(o);
    if (!n || !this.selectedActorId) {
      (i = ui.notifications) == null || i.warn("Select a party member first.");
      return;
    }
    v.emit(I.GM_GRANT, {
      actorId: this.selectedActorId,
      item: {
        definitionId: o,
        name: n.name,
        quantity: 1,
        zone: "stowed",
        isSecret: !1,
        notes: ""
      }
    }), (s = ui.notifications) == null || s.info(`Granted ${n.name}.`);
  }
  static _onAddCustomItem() {
    var a;
    if (!this.selectedActorId) {
      (a = ui.notifications) == null || a.warn("Select a party member first.");
      return;
    }
    const t = this.selectedActorId;
    new Dialog({
      title: "Add Custom Item",
      content: `
        <form>
          <div class="form-group">
            <label>Item Name</label>
            <input type="text" id="custom-name" placeholder="Custom item name" />
          </div>
          <div class="form-group">
            <label>Size</label>
            <select id="custom-size">
              <option value="tiny">Tiny (0 slots)</option>
              <option value="normal" selected>Normal (1 slot)</option>
              <option value="large">Large (2 slots)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="custom-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="custom-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
          <div class="form-group">
            <label>Secret?</label>
            <input type="checkbox" id="custom-secret" />
          </div>
        </form>
      `,
      buttons: {
        add: {
          label: "Grant Item",
          callback: (o) => {
            const n = o.find("#custom-name").val().trim();
            if (!n) return;
            const i = o.find("#custom-size").val(), s = Math.max(1, parseInt(o.find("#custom-qty").val(), 10) || 1), c = o.find("#custom-zone").val(), l = o.find("#custom-secret").prop("checked");
            v.emit(I.GM_GRANT, {
              actorId: t,
              item: {
                definitionId: "",
                name: n,
                quantity: s,
                zone: c,
                isSecret: l,
                notes: "",
                customDefinition: { size: i, isCustom: !0 }
              }
            });
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    }).render(!0);
  }
};
b(T, "DEFAULT_OPTIONS", {
  id: "dolmenwood-shop",
  window: {
    title: "Shop",
    resizable: !0
  },
  position: {
    width: 700,
    height: 640
  },
  classes: ["dolmenwood-party-inventory", "shop"],
  actions: {
    toggleTag: T._onToggleTag,
    purchaseItem: T._onPurchaseItem,
    grantItem: T._onGrantItem,
    addCustomItem: T._onAddCustomItem
  }
}), b(T, "PARTS", {
  content: {
    template: P.SHOP
  }
});
let _ = T;
const S = class S extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor(t, a) {
    super(a);
    b(this, "actor");
    this.actor = t;
  }
  get title() {
    return `${this.actor.name} — Inventory`;
  }
  async _prepareContext(t) {
    var f;
    const a = game, o = p.getInventory(this.actor), n = H(o, q.getMap()), i = ((f = a.user) == null ? void 0 : f.isGM) ?? !1, s = this.actor.isOwner, c = o.items.filter(
      (u) => !u.isSecret || i || s
    ), l = {
      tiny: c.filter((u) => u.zone === "tiny"),
      equipped: c.filter((u) => u.zone === "equipped"),
      stowed: c.filter((u) => u.zone === "stowed")
    }, d = (u) => u.map((y) => ({
      ...y,
      def: q.getDefinition(y.definitionId)
    })), h = a.settings.get(g, "partyActorIds").map((u) => {
      var y;
      return (y = a.actors) == null ? void 0 : y.get(u);
    }).filter((u) => !!u && u.id !== this.actor.id);
    return {
      actor: this.actor,
      actorId: this.actor.id,
      inventory: o,
      zones: {
        tiny: d(l.tiny),
        equipped: d(l.equipped),
        stowed: d(l.stowed)
      },
      encumbrance: n,
      isGM: i,
      isOwner: s,
      canEdit: i || s,
      partyMembers: h,
      transactions: i ? p.getTransactions() : []
    };
  }
  _onRender(t, a) {
    const o = this.element;
    o.querySelectorAll(".item-zone-select").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const s = i.target.dataset.itemId, c = i.target.value;
        await p.updateInventory(this.actor, (l) => {
          const d = l.items.find((m) => m.id === s);
          return d && (d.zone = c), l;
        }), this.render();
      });
    }), o.querySelectorAll(".item-notes-input").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const s = i.target.dataset.itemId, c = i.target.value;
        await p.updateInventory(this.actor, (l) => {
          const d = l.items.find((m) => m.id === s);
          return d && (d.notes = c), l;
        });
      });
    }), o.querySelectorAll(".coin-input").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const s = i.target.dataset.currency, c = Math.max(0, parseInt(i.target.value, 10) || 0);
        await p.updateInventory(this.actor, (l) => (l.coins[s] = c, l)), this.render();
      });
    });
  }
  // ─── Action Handlers ──────────────────────────────────────────────────────
  static async _onIncrementQty(t, a) {
    const o = a.dataset.itemId;
    await p.updateInventory(this.actor, (n) => {
      const i = n.items.find((s) => s.id === o);
      return i && (i.quantity = Math.max(1, i.quantity + 1)), n;
    }), this.render();
  }
  static async _onDecrementQty(t, a) {
    const o = a.dataset.itemId;
    await p.updateInventory(this.actor, (n) => {
      const i = n.items.find((s) => s.id === o);
      return i && (i.quantity = Math.max(1, i.quantity - 1)), n;
    }), this.render();
  }
  static async _onDeleteItem(t, a) {
    const o = a.dataset.itemId;
    await Dialog.confirm({
      title: "Remove Item",
      content: "<p>Remove this item from inventory?</p>"
    }) && (await p.updateInventory(this.actor, (i) => (i.items = i.items.filter((s) => s.id !== o), i)), this.render());
  }
  static async _onToggleSecret(t, a) {
    const o = a.dataset.itemId;
    await p.updateInventory(this.actor, (n) => {
      const i = n.items.find((s) => s.id === o);
      return i && (i.isSecret = !i.isSecret), n;
    }), this.render();
  }
  static _onAddItem(t, a) {
    const o = a.dataset.zone ?? "equipped";
    new X(this.actor, o, () => this.render()).render(!0);
  }
  static _onGiveItem(t, a) {
    const o = a.dataset.itemId;
    new ee(this.actor, o, () => this.render()).render(!0);
  }
};
b(S, "DEFAULT_OPTIONS", {
  id: "dolmenwood-player-inventory",
  window: {
    title: "Inventory",
    resizable: !0
  },
  position: {
    width: 520,
    height: 700
  },
  classes: ["dolmenwood-party-inventory", "player-inventory"],
  actions: {
    addItem: S._onAddItem,
    deleteItem: S._onDeleteItem,
    toggleSecret: S._onToggleSecret,
    giveItem: S._onGiveItem,
    incrementQty: S._onIncrementQty,
    decrementQty: S._onDecrementQty
  }
}), b(S, "PARTS", {
  content: {
    template: P.PLAYER_INVENTORY
  }
});
let R = S;
class X extends Dialog {
  constructor(t, a, o) {
    const n = q.getAllDefinitions(), i = {};
    for (const c of n)
      i[c.category] || (i[c.category] = ""), i[c.category] += `<option value="${c.id}">${c.name} (${c.size}, ${c.cost.amount} ${c.cost.currency})</option>`;
    let s = "";
    for (const [c, l] of Object.entries(i))
      s += `<optgroup label="${c}">${l}</optgroup>`;
    super({
      title: "Add Item to Inventory",
      content: `
        <form>
          <div class="form-group">
            <label>Item</label>
            <select id="add-item-select">${s}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="add-item-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="add-item-zone">
              <option value="equipped" ${a === "equipped" ? "selected" : ""}>Equipped</option>
              <option value="stowed" ${a === "stowed" ? "selected" : ""}>Stowed</option>
              <option value="tiny" ${a === "tiny" ? "selected" : ""}>Tiny</option>
            </select>
          </div>
          <hr/>
          <details>
            <summary>Add Custom Item Instead</summary>
            <div class="form-group">
              <label>Custom Name</label>
              <input type="text" id="add-custom-name" placeholder="Custom item name" />
            </div>
            <div class="form-group">
              <label>Custom Size</label>
              <select id="add-custom-size">
                <option value="tiny">Tiny (0 slots)</option>
                <option value="normal" selected>Normal (1 slot)</option>
                <option value="large">Large (2 slots)</option>
              </select>
            </div>
          </details>
        </form>
      `,
      buttons: {
        add: {
          label: "Add",
          callback: async (c) => {
            const l = c.find("#add-custom-name").val().trim(), d = Math.max(1, parseInt(c.find("#add-item-qty").val(), 10) || 1), m = c.find("#add-item-zone").val();
            if (l) {
              const h = c.find("#add-custom-size").val();
              await p.updateInventory(t, (f) => (f.items.push({
                id: foundry.utils.randomID(),
                definitionId: "",
                name: l,
                quantity: d,
                zone: m,
                isSecret: !1,
                notes: "",
                customDefinition: { size: h, isCustom: !0 }
              }), f));
            } else {
              const h = c.find("#add-item-select").val(), f = q.getDefinition(h);
              if (!f) return;
              await p.updateInventory(t, (u) => (u.items.push({
                id: foundry.utils.randomID(),
                definitionId: h,
                name: f.name,
                quantity: d,
                zone: m,
                isSecret: !1,
                notes: ""
              }), u));
            }
            o();
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    });
    b(this, "actor");
    b(this, "zone");
    b(this, "onComplete");
    this.actor = t, this.zone = a, this.onComplete = o;
  }
}
class ee extends Dialog {
  constructor(e, t, a) {
    const o = game, s = o.settings.get(g, "partyActorIds").map((d) => {
      var m;
      return (m = o.actors) == null ? void 0 : m.get(d);
    }).filter((d) => !!d && d.id !== e.id).map((d) => `<option value="${d.id}">${d.name}</option>`).join(""), l = p.getInventory(e).items.find((d) => d.id === t);
    l && super({
      title: `Give ${l.name}`,
      content: `
        <form>
          <div class="form-group">
            <label>Give to</label>
            <select id="give-item-target">${s}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="give-item-qty" value="1" min="1" max="${l.quantity}" />
          </div>
        </form>
      `,
      buttons: {
        give: {
          label: "Give",
          callback: async (d) => {
            var u;
            const m = d.find("#give-item-target").val(), h = Math.min(
              l.quantity,
              Math.max(1, parseInt(d.find("#give-item-qty").val(), 10) || 1)
            );
            (u = o.actors) != null && u.get(m) && (await p.updateInventory(e, (y) => {
              const C = y.items.find((w) => w.id === t);
              return C && (C.quantity -= h, C.quantity <= 0 && (y.items = y.items.filter((w) => w.id !== t))), y;
            }), v.emit(I.GM_GRANT, {
              actorId: m,
              item: {
                definitionId: l.definitionId,
                name: l.name,
                quantity: h,
                zone: l.zone,
                isSecret: !1,
                notes: "",
                customDefinition: l.customDefinition
              }
            }), a());
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "give"
    });
  }
}
const z = class z extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  async _prepareContext(e) {
    var i;
    const t = game, o = t.settings.get(g, "partyActorIds").map((s) => {
      var h;
      const c = (h = t.actors) == null ? void 0 : h.get(s);
      if (!c) return null;
      const l = p.getInventory(c), d = H(l, q.getMap()), m = {};
      for (const f of l.items)
        m[f.zone] || (m[f.zone] = []);
      return {
        actor: c,
        actorId: c.id,
        inventory: l,
        encumbrance: d,
        isOwner: c.isOwner
      };
    }).filter(Boolean), n = {
      cp: 0,
      sp: 0,
      gp: 0,
      pp: 0
    };
    for (const s of o)
      s && (n.cp += s.inventory.coins.cp, n.sp += s.inventory.coins.sp, n.gp += s.inventory.coins.gp, n.pp += s.inventory.coins.pp);
    return {
      members: o,
      partyTotals: n,
      isGM: ((i = t.user) == null ? void 0 : i.isGM) ?? !1,
      transactions: p.getTransactions().slice(-20).reverse()
    };
  }
  _onRender(e, t) {
    this.element.querySelectorAll(".player-column[data-actor-id]").forEach((a) => {
      a.addEventListener("click", (o) => {
        var s;
        if (o.target.closest("button")) return;
        const n = a.dataset.actorId, i = (s = game.actors) == null ? void 0 : s.get(n);
        i && new R(i).render(!0);
      });
    });
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static _onOpenShop() {
    new _().render(!0);
  }
  static _onOpenPlayerInventory(e, t) {
    var n;
    const a = t.dataset.actorId, o = (n = game.actors) == null ? void 0 : n.get(a);
    o && new R(o).render(!0);
  }
  static async _onManageParty() {
    var n;
    const e = game, t = (((n = e.actors) == null ? void 0 : n.contents) ?? []).filter((i) => i.type === "character"), a = e.settings.get(g, "partyActorIds"), o = t.map(
      (i) => `<div class="form-group">
            <input type="checkbox" id="party-${i.id}" name="${i.id}"
              ${a.includes(i.id) ? "checked" : ""} />
            <label for="party-${i.id}">${i.name}</label>
          </div>`
    ).join("");
    new Dialog({
      title: "Manage Party Members",
      content: `<form><p>Select actors to include in the party overview:</p>${o}</form>`,
      buttons: {
        save: {
          label: "Save",
          callback: async (i) => {
            const s = t.filter((c) => i.find(`[name="${c.id}"]`).prop("checked")).map((c) => c.id);
            await e.settings.set(g, "partyActorIds", s), this.render();
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "save"
    }).render(!0);
  }
};
b(z, "DEFAULT_OPTIONS", {
  id: "dolmenwood-party-overview",
  window: {
    title: "Party Inventory Overview",
    resizable: !0
  },
  position: {
    width: 960,
    height: 620
  },
  classes: ["dolmenwood-party-inventory", "party-overview"],
  actions: {
    openShop: z._onOpenShop,
    openPlayerInventory: z._onOpenPlayerInventory,
    manageParty: z._onManageParty
  }
}), b(z, "PARTS", {
  content: {
    template: P.PARTY_OVERVIEW
  }
});
let O = z;
Hooks.once("init", () => {
  console.log(`${g} | Initializing`), game.settings.register(g, E.PARTY_ACTOR_IDS, {
    name: "Party Members",
    hint: "Actor IDs of characters included in the party overview.",
    scope: "world",
    config: !1,
    type: Array,
    default: []
  }), game.settings.register(g, E.SHOP_STATE, {
    name: "Shop State",
    hint: "Active tags and available items for the shop panel.",
    scope: "world",
    config: !1,
    type: Object,
    default: { activeTags: [], availableItems: [] }
  }), game.settings.register(g, k.TRANSACTION_LOG, {
    name: "Transaction Log",
    scope: "world",
    config: !1,
    type: Array,
    default: []
  }), Z();
});
Hooks.once("ready", async () => {
  var t, a;
  console.log(`${g} | Ready`), await K(), v.initialize();
  const r = game.modules.get(g);
  r && (r.api = {
    openPartyOverview: () => F(),
    openPlayerInventory: (o) => W(o),
    openShop: () => te()
  });
  const e = game;
  !((t = e.user) != null && t.isGM) && ((a = e.user) != null && a.character) && W(e.user.character);
});
Hooks.on("updateActor", (r, e) => {
  var o, n, i, s;
  if (!((o = e.flags) == null ? void 0 : o[g])) return;
  const a = (n = foundry.applications) == null ? void 0 : n.instances;
  if (a)
    for (const c of a.values()) {
      const l = c.id ?? "";
      if (l === "dolmenwood-party-overview")
        (i = c.render) == null || i.call(c);
      else if (l === "dolmenwood-player-inventory") {
        const d = c;
        ((s = d.actor) == null ? void 0 : s.id) === r.id && d.render();
      }
    }
});
Hooks.on("getSceneControlButtons", (r) => {
  var a;
  if (!((a = game.user) != null && a.isGM)) return;
  const t = r.find((o) => o.name === "token");
  t && t.tools.push({
    name: "dolmenwood-party-inventory",
    title: "Party Inventory",
    icon: "fas fa-backpack",
    button: !0,
    onClick: () => F()
  });
});
function F() {
  var t, a;
  if (!((t = game.user) != null && t.isGM)) {
    (a = ui.notifications) == null || a.warn("Only the GM can access the Party Overview.");
    return;
  }
  const e = D("dolmenwood-party-overview");
  e ? e.render({ force: !0 }) : new O().render(!0);
}
function W(r) {
  var o, n, i;
  const e = game;
  let t;
  if (typeof r == "string" ? t = (o = e.actors) == null ? void 0 : o.get(r) : r instanceof Actor ? t = r : t = ((n = e.user) == null ? void 0 : n.character) ?? void 0, !t) {
    (i = ui.notifications) == null || i.warn("No actor found. Assign a character to your user first.");
    return;
  }
  const a = D("dolmenwood-player-inventory");
  a ? a.render({ force: !0 }) : new R(t).render(!0);
}
function te() {
  var t, a;
  if (!((t = game.user) != null && t.isGM)) {
    (a = ui.notifications) == null || a.warn("Only the GM can open the Shop.");
    return;
  }
  const e = D("dolmenwood-shop");
  e ? e.render({ force: !0 }) : new _().render(!0);
}
function D(r) {
  var t;
  const e = (t = foundry.applications) == null ? void 0 : t.instances;
  if (e) {
    for (const a of e.values())
      if (a.id === r)
        return a;
  }
}
//# sourceMappingURL=module.js.map
