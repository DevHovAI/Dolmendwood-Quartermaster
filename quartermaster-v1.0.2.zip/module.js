var V = Object.defineProperty;
var Q = (s, e, t) => e in s ? V(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var A = (s, e, t) => Q(s, typeof e != "symbol" ? e + "" : e, t);
const p = "dolmenwood-party-inventory", E = {
  INVENTORY: "inventory",
  TRANSACTION_LOG: "transactionLog"
}, z = {
  PARTY_OVERVIEW: `modules/${p}/templates/party-overview.hbs`,
  PLAYER_INVENTORY: `modules/${p}/templates/player-inventory.hbs`,
  SHOP: `modules/${p}/templates/shop.hbs`,
  PARTIALS: {
    INVENTORY_ZONE: `modules/${p}/templates/partials/inventory-zone.hbs`,
    ITEM_ROW: `modules/${p}/templates/partials/item-row.hbs`,
    COIN_DISPLAY: `modules/${p}/templates/partials/coin-display.hbs`,
    ENCUMBRANCE_BAR: `modules/${p}/templates/partials/encumbrance-bar.hbs`,
    TRANSACTION_LOG: `modules/${p}/templates/partials/transaction-log.hbs`
  }
}, I = {
  PURCHASE_ITEM: "purchaseItem",
  GM_GRANT: "gmGrant",
  GM_REMOVE: "gmRemove",
  REQUEST_REFRESH: "requestRefresh"
}, _ = {
  SHOP_STATE: "shopState"
}, N = `module.${p}`, U = [
  [0, 3, 40],
  [4, 5, 30],
  [6, 7, 20],
  [8, 10, 10]
], Y = [
  [0, 10, 40],
  [11, 12, 30],
  [13, 14, 20],
  [15, 16, 10]
];
function D(s, e) {
  for (const [t, o, a] of e)
    if (s >= t && s <= o) return a;
  return 10;
}
function x(s, e) {
  var w;
  let t = 0, o = 0, a = 0;
  for (const B of s.items) {
    const P = e.get(B.definitionId), M = ((w = B.customDefinition) == null ? void 0 : w.size) ?? (P == null ? void 0 : P.size) ?? "normal", G = B.quantity;
    B.zone === "tiny" ? a += G : B.zone === "equipped" ? M === "tiny" || (M === "normal" ? t += G : M === "large" && (t += G * 2)) : B.zone === "stowed" && (M === "tiny" ? a += G : M === "normal" ? o += G : M === "large" && (o += G * 2));
  }
  const n = Math.max(0, 10 - a), i = Math.max(0, a - 10);
  o += Math.ceil(i / 10);
  const { cp: r, sp: c, gp: l, pp: d } = s.coins, g = r + c * 10 + l * 100 + d * 500, f = Math.floor(g / 100);
  o += f;
  const h = D(t, U), u = D(o, Y), y = Math.min(h, u);
  let b = "none";
  return h < u ? b = "equipped" : u < h ? b = "stowed" : y < 40 && (b = "both"), {
    equippedSlots: t,
    stowedSlots: o,
    equippedSpeed: h,
    stowedSpeed: u,
    finalSpeed: y,
    bottleneck: b,
    tinyCount: a,
    freeTinySlots: n,
    tinyOverflow: i,
    coinSlots: f
  };
}
function j(s) {
  switch (s) {
    case 40:
      return "speed-green";
    case 30:
      return "speed-yellow";
    case 20:
      return "speed-orange";
    case 10:
      return "speed-red";
  }
}
function Z() {
  Handlebars.registerHelper("eq", (s, e) => s === e), Handlebars.registerHelper("neq", (s, e) => s !== e), Handlebars.registerHelper("gt", (s, e) => s > e), Handlebars.registerHelper("lt", (s, e) => s < e), Handlebars.registerHelper(
    "formatCost",
    (s, e) => `${s} ${e}`
  ), Handlebars.registerHelper(
    "speedColor",
    (s) => j(s)
  ), Handlebars.registerHelper(
    "equippedBarWidth",
    (s) => Math.min(100, s / 10 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper(
    "stowedBarWidth",
    (s) => Math.min(100, s / 16 * 100).toFixed(1) + "%"
  ), Handlebars.registerHelper("bottleneckLabel", (s) => {
    switch (s) {
      case "equipped":
        return "Equipped";
      case "stowed":
        return "Stowed";
      case "both":
        return "Both";
      default:
        return "";
    }
  }), Handlebars.registerHelper(
    "coinTotal",
    (s, e, t, o) => {
      const a = [];
      return o > 0 && a.push(`${o} pp`), t > 0 && a.push(`${t} gp`), e > 0 && a.push(`${e} sp`), s > 0 && a.push(`${s} cp`), a.length > 0 ? a.join(", ") : "0 gp";
    }
  ), Handlebars.registerHelper("sizeLabel", (s) => {
    switch (s) {
      case "tiny":
        return "Tiny";
      case "normal":
        return "Normal";
      case "large":
        return "Large";
      default:
        return s;
    }
  }), Handlebars.registerHelper("slotCost", (s) => {
    switch (s) {
      case "tiny":
        return "0 slots";
      case "normal":
        return "1 slot";
      case "large":
        return "2 slots";
      default:
        return "-";
    }
  });
}
async function K() {
  await loadTemplates({
    "transaction-log": z.PARTIALS.TRANSACTION_LOG,
    "inventory-zone": z.PARTIALS.INVENTORY_ZONE,
    "item-row": z.PARTIALS.ITEM_ROW,
    "coin-display": z.PARTIALS.COIN_DISPLAY,
    "encumbrance-bar": z.PARTIALS.ENCUMBRANCE_BAR
  });
}
function J(s) {
  return {
    actorId: s,
    coins: { cp: 0, sp: 0, gp: 0, pp: 0 },
    items: []
  };
}
class m {
  static getInventory(e) {
    return e.getFlag(p, E.INVENTORY) ?? J(e.id ?? "");
  }
  static async setInventory(e, t) {
    await e.setFlag(p, E.INVENTORY, t);
  }
  static async updateInventory(e, t) {
    const o = this.getInventory(e), a = t(structuredClone(o));
    await this.setInventory(e, a);
  }
  static getTransactions() {
    return game.settings.get(p, E.TRANSACTION_LOG) ?? [];
  }
  static async appendTransaction(e) {
    const t = this.getTransactions();
    t.push(e);
    const o = t.slice(-200);
    await game.settings.set(p, E.TRANSACTION_LOG, o);
  }
}
class C {
  static initialize() {
    game.socket.on(
      N,
      (e) => C.handleIncoming(e)
    );
  }
  /**
   * Emit a socket event to all clients (including ourselves, handled locally too).
   */
  static emit(e, t) {
    const o = {
      event: e,
      data: t,
      userId: game.user.id
    };
    game.socket.emit(N, o);
  }
  static handleIncoming(e) {
    var o, a, n;
    const t = game;
    switch (e.event) {
      case I.GM_GRANT:
        (o = t.user) != null && o.isGM && C.onGMGrant(e.data);
        break;
      case I.GM_REMOVE:
        (a = t.user) != null && a.isGM && C.onGMRemove(e.data);
        break;
      case I.PURCHASE_ITEM:
        (n = t.user) != null && n.isGM && C.onPurchase(e.data);
        break;
      case I.REQUEST_REFRESH:
        C.onRequestRefresh();
        break;
    }
  }
  static async onGMGrant(e) {
    var n;
    const t = (n = game.actors) == null ? void 0 : n.get(e.actorId);
    if (!t) return;
    const o = {
      ...e.item,
      id: foundry.utils.randomID()
    };
    await m.updateInventory(t, (i) => (i.items.push(o), i));
    const a = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "gm_grant",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: o.definitionId, name: o.name, quantity: o.quantity }],
      coinsDelta: []
    };
    await m.appendTransaction(a), C.emit(I.REQUEST_REFRESH, {});
  }
  static async onGMRemove(e) {
    var a;
    const t = (a = game.actors) == null ? void 0 : a.get(e.actorId);
    if (!t) return;
    let o;
    if (await m.updateInventory(t, (n) => {
      const i = n.items.findIndex((r) => r.id === e.itemId);
      if (i !== -1) {
        const [r] = n.items.splice(i, 1);
        o = { definitionId: r.definitionId, name: r.name, quantity: r.quantity };
      }
      return n;
    }), o) {
      const n = {
        id: foundry.utils.randomID(),
        timestamp: Date.now(),
        type: "gm_remove",
        fromActorId: e.actorId,
        toActorId: "shop",
        items: [o],
        coinsDelta: []
      };
      await m.appendTransaction(n);
    }
    C.emit(I.REQUEST_REFRESH, {});
  }
  static async onPurchase(e) {
    var a;
    const t = (a = game.actors) == null ? void 0 : a.get(e.actorId);
    if (!t) return;
    await m.updateInventory(t, (n) => {
      const i = (e.totalCost.cp ?? 0) + (e.totalCost.sp ?? 0) * 10 + (e.totalCost.gp ?? 0) * 100 + (e.totalCost.pp ?? 0) * 500, r = n.coins.cp + n.coins.sp * 10 + n.coins.gp * 100 + n.coins.pp * 500;
      if (r < i) return n;
      const c = r - i;
      return n.coins.pp = 0, n.coins.gp = Math.floor(c / 100), n.coins.sp = Math.floor(c % 100 / 10), n.coins.cp = c % 10, n.items.push({
        id: foundry.utils.randomID(),
        definitionId: e.definitionId,
        name: e.definitionId,
        // will be resolved by UI from catalog
        quantity: e.quantity,
        zone: e.zone,
        isSecret: !1,
        notes: ""
      }), n;
    });
    const o = {
      id: foundry.utils.randomID(),
      timestamp: Date.now(),
      type: "purchase",
      fromActorId: "shop",
      toActorId: e.actorId,
      items: [{ definitionId: e.definitionId, name: e.definitionId, quantity: e.quantity }],
      coinsDelta: [
        {
          actorId: e.actorId,
          cp: -e.totalCost.cp,
          sp: -e.totalCost.sp,
          gp: -e.totalCost.gp,
          pp: -e.totalCost.pp
        }
      ]
    };
    await m.appendTransaction(o), C.emit(I.REQUEST_REFRESH, {});
  }
  static onRequestRefresh() {
    var e, t;
    for (const o of Object.values(((e = foundry.applications) == null ? void 0 : e.instances) ?? {}))
      (o.id ?? "").startsWith("dolmenwood-") && ((t = o.render) == null || t.call(o));
  }
}
const v = [
  // ─── ARMOUR ───────────────────────────────────────────────────────────────
  {
    id: "unarmoured",
    name: "Unarmoured",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "gp" },
    weight: 0,
    description: "No armour. AC 10.",
    qualities: ["AC 10"],
    tags: [],
    isCustom: !1
  },
  {
    id: "leather-armour",
    name: "Leather Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 200,
    description: "Light armour made of hardened leather. AC 12.",
    qualities: ["AC 12"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bark-armour",
    name: "Bark Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 300,
    description: "Armour crafted from treated tree bark. AC 13.",
    qualities: ["AC 13"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chainmail",
    name: "Chainmail",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 400,
    description: "Interlocking metal rings. AC 14.",
    qualities: ["AC 14"],
    tags: [],
    isCustom: !1
  },
  {
    id: "pinecone-armour",
    name: "Pinecone Armour",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 400,
    description: "Armour fashioned from overlapping pinecone scales. AC 15.",
    qualities: ["AC 15"],
    tags: [],
    isCustom: !1
  },
  {
    id: "plate-mail",
    name: "Plate Mail",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 60, currency: "gp" },
    weight: 500,
    description: "Heavy plate armour. AC 16.",
    qualities: ["AC 16"],
    tags: [],
    isCustom: !1
  },
  {
    id: "full-plate",
    name: "Full Plate",
    category: "Armour",
    subcategory: "Armour",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1e3, currency: "gp" },
    weight: 700,
    description: "The finest and heaviest plate armour. AC 17.",
    qualities: ["AC 17"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shield",
    name: "Shield",
    category: "Armour",
    subcategory: "Armour",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A wooden or metal shield. AC +1.",
    qualities: ["AC +1"],
    tags: [],
    isCustom: !1
  },
  // ─── WEAPONS ──────────────────────────────────────────────────────────────
  {
    id: "battle-axe",
    name: "Battle Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 100,
    description: "A heavy two-handed axe. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "club",
    name: "Club",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 20,
    description: "A heavy wooden club. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "crossbow",
    name: "Crossbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 50,
    description: "A mechanical ranged weapon. 1d8 damage.",
    qualities: ["1d8", "Missile (80/160/240)", "Reload", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "dagger",
    name: "Dagger",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "A short blade useful in melee and as a thrown weapon. 1d4 damage.",
    qualities: ["Melee", "1d4", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "hand-axe",
    name: "Hand Axe",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 20,
    description: "A small axe, usable in melee or thrown. 1d6 damage.",
    qualities: ["Melee", "1d6", "Missile (10/20/30)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial",
    name: "Holy Water (Vial)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "Blessed water, effective against undead when thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "lance",
    name: "Lance",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !0,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 100,
    description: "A long cavalry weapon. 1d6 damage. Cannot be stowed.",
    qualities: ["Brace", "Charge", "Melee", "1d6", "Reach"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longbow",
    name: "Longbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 40, currency: "gp" },
    weight: 40,
    description: "A tall war bow with long range. 1d8 damage.",
    qualities: ["1d8", "Missile (70/140/210)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "longsword",
    name: "Longsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "A versatile one-handed sword. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "mace",
    name: "Mace",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy-headed bludgeoning weapon. 1d8 damage.",
    qualities: ["Melee", "1d8"],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask-burning",
    name: "Oil Flask (Burning)",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of oil set alight and thrown. 1d8 damage.",
    qualities: ["1d8", "Missile (10/30/50)", "Splash"],
    tags: [],
    isCustom: !1
  },
  {
    id: "polearm",
    name: "Polearm",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 140,
    description: "A long hafted weapon with a blade or head. 1d10 damage.",
    qualities: ["Brace", "Melee", "1d10", "Reach", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortbow",
    name: "Shortbow",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A compact bow for skirmishing. 1d6 damage.",
    qualities: ["1d6", "Missile (50/100/150)", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "shortsword",
    name: "Shortsword",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 7, currency: "gp" },
    weight: 20,
    description: "A short, light blade. 1d6 damage.",
    qualities: ["Melee", "1d6"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling",
    name: "Sling",
    category: "Weapons",
    subcategory: "Missile",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 10,
    description: "A simple ranged weapon using stones. 1d4 damage.",
    qualities: ["1d4", "Missile (40/80/160)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "spear",
    name: "Spear",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 30,
    description: "A thrusting weapon, useful in melee and as a thrown weapon. 1d6 damage.",
    qualities: ["Brace", "Melee", "1d6", "Missile (20/40/60)"],
    tags: [],
    isCustom: !1
  },
  {
    id: "staff",
    name: "Staff",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 40,
    description: "A long wooden staff. 1d6 damage.",
    qualities: ["Melee", "1d6", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "torch-flaming",
    name: "Torch (Flaming)",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 15,
    description: "A lit torch used as an improvised weapon. 1d4 damage. Sold in sets of 3.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  {
    id: "two-handed-sword",
    name: "Two-Handed Sword",
    category: "Weapons",
    subcategory: "Melee",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 140,
    description: "A massive greatsword requiring both hands. 1d10 damage.",
    qualities: ["Melee", "1d10", "Two-handed"],
    tags: [],
    isCustom: !1
  },
  {
    id: "war-hammer",
    name: "War Hammer",
    category: "Weapons",
    subcategory: "Melee",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "A heavy hammer for smashing armour. 1d4 damage.",
    qualities: ["Melee", "1d4"],
    tags: [],
    isCustom: !1
  },
  // ─── AMMUNITION ───────────────────────────────────────────────────────────
  {
    id: "arrows-quiver",
    name: "Arrows (Quiver of 20)",
    category: "Ammunition",
    subcategory: "Arrows",
    size: "normal",
    cannotBeStowed: !1,
    unit: "quiver",
    cost: { amount: 5, currency: "cp" },
    weight: 20,
    description: "A quiver of 20 arrows for use with bows.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quarrels-case",
    name: "Quarrels (Case of 20)",
    category: "Ammunition",
    subcategory: "Quarrels",
    size: "normal",
    cannotBeStowed: !1,
    unit: "case",
    cost: { amount: 10, currency: "cp" },
    weight: 20,
    description: "A case of 20 crossbow quarrels.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "sling-stones",
    name: "Sling Stones",
    category: "Ammunition",
    subcategory: "Stones",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 0, currency: "cp" },
    weight: 1,
    description: "Smooth stones for use with a sling. Free to acquire.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CONTAINERS ────────────────────────────────────────
  {
    id: "backpack",
    name: "Backpack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A sturdy canvas backpack. Capacity: 400 coins.",
    qualities: ["Capacity: 400 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "barrel",
    name: "Barrel",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 70,
    description: "A wooden barrel. Capacity: 320 pints.",
    qualities: ["Capacity: 320 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "belt-pouch",
    name: "Belt Pouch",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A small leather pouch worn on the belt. Capacity: 50 coins.",
    qualities: ["Capacity: 50 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "bucket",
    name: "Bucket",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "A wooden or metal bucket. Capacity: 40 pints.",
    qualities: ["Capacity: 40 pints"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-large",
    name: "Casket (Iron, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 400,
    description: "A large iron strongbox. Capacity: 800 coins.",
    qualities: ["Capacity: 800 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "casket-iron-small",
    name: "Casket (Iron, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 100,
    description: "A small iron strongbox. Capacity: 250 coins.",
    qualities: ["Capacity: 250 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-large",
    name: "Chest (Wooden, Large)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 200,
    description: "A large wooden chest. Capacity: 1000 coins.",
    qualities: ["Capacity: 1000 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "chest-wooden-small",
    name: "Chest (Wooden, Small)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A small wooden chest. Capacity: 300 coins.",
    qualities: ["Capacity: 300 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "sack",
    name: "Sack",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A large cloth sack. Capacity: 600 coins.",
    qualities: ["Capacity: 600 coins"],
    tags: [],
    isCustom: !1
  },
  {
    id: "scroll-case",
    name: "Scroll Case",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A protective tube for scrolls and maps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "vial-glass",
    name: "Vial (Glass)",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small glass vial. Capacity: 0.5 pint.",
    qualities: ["Capacity: 0.5 pint"],
    tags: [],
    isCustom: !1
  },
  {
    id: "waterskin",
    name: "Waterskin",
    category: "Adventuring Gear",
    subcategory: "Containers",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A leather flask for carrying water. Capacity: 2 pints.",
    qualities: ["Capacity: 2 pints"],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — LIGHT ─────────────────────────────────────────────
  {
    id: "candles-10",
    name: "Candles (10)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Ten tallow candles, providing dim light for 1 hour each.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-hooded",
    name: "Lantern (Hooded)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 20,
    description: "A lantern with adjustable hood to control light.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lantern-bullseye",
    name: "Lantern (Bullseye)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 20,
    description: "A lantern that focuses light in a cone.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "oil-flask",
    name: "Oil (Flask)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A flask of lamp oil, fueling a lantern for 4 hours.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tinder-box",
    name: "Tinder Box",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 10,
    description: "Steel, flint, and tinder for starting fires.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "torches-3",
    name: "Torches (3)",
    category: "Adventuring Gear",
    subcategory: "Light",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Three wooden torches, each burning for 1 hour.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CAMPING AND TRAVEL ────────────────────────────────
  {
    id: "bedroll",
    name: "Bedroll",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 70,
    description: "A rolled sleeping mat and blanket.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "cooking-pots",
    name: "Cooking Pots",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 3, currency: "gp" },
    weight: 100,
    description: "A set of iron cooking pots for camp meals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "firewood-bundle",
    name: "Firewood (Bundle, 8 hours)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 200,
    description: "A bundle of firewood sufficient for 8 hours of burning.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "fishing-rod-and-tackle",
    name: "Fishing Rod and Tackle",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 4, currency: "gp" },
    weight: 50,
    description: "A rod, line, and hook for fishing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-preserved",
    name: "Rations (Preserved, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Hard tack, jerky, and dried goods lasting one day.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rations-fresh",
    name: "Rations (Fresh, 1 Day)",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "day",
    cost: { amount: 1, currency: "gp" },
    weight: 20,
    description: "Fresh food for one day — must be consumed within a few days.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "tent",
    name: "Tent",
    category: "Adventuring Gear",
    subcategory: "Camping and Travel",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "A canvas tent sheltering up to two people.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — HOLY ITEMS ────────────────────────────────────────
  {
    id: "holy-symbol-gold",
    name: "Holy Symbol (Gold)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 20,
    description: "A golden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-silver",
    name: "Holy Symbol (Silver)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 20,
    description: "A silver holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-symbol-wooden",
    name: "Holy Symbol (Wooden)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A carved wooden holy symbol of a deity.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "holy-water-vial-gear",
    name: "Holy Water (Vial)",
    category: "Adventuring Gear",
    subcategory: "Holy Items",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 25, currency: "gp" },
    weight: 10,
    description: "A vial of blessed water, effective against undead.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — MISCELLANEOUS TOOLS ───────────────────────────────
  {
    id: "bell-miniature",
    name: "Bell (Miniature)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "A small bell useful for alarms and signals.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "block-and-tackle",
    name: "Block and Tackle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "A pulley system for hoisting heavy loads.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "caltrops-bag",
    name: "Caltrops (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "Metal spikes scattered to slow pursuit.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chain-10ft",
    name: "Chain (10' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 100,
    description: "Ten feet of iron chain.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chalk-10-sticks",
    name: "Chalk (10 Sticks)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 5,
    description: "Ten sticks of chalk for marking walls and floors.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "chisel",
    name: "Chisel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A metal chisel for cutting stone and wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "crowbar",
    name: "Crowbar",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "An iron pry bar for forcing doors and shifting stones.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "grappling-hook",
    name: "Grappling Hook",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 40,
    description: "An iron hook for climbing walls and crossing gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-small",
    name: "Hammer (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 15,
    description: "A small hammer for driving spikes and basic carpentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "hammer-sledgehammer",
    name: "Hammer (Sledgehammer)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy hammer for breaking rock and forcing barriers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "ink-vial",
    name: "Ink (Vial)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 8, currency: "gp" },
    weight: 5,
    description: "A vial of black writing ink.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "iron-spikes-12",
    name: "Iron Spikes (12)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "A dozen iron spikes for pitons, door-spiking, and general use.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "lock",
    name: "Lock",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 20,
    description: "An iron padlock with key.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "magnifying-glass",
    name: "Magnifying Glass",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 5,
    description: "A glass lens for examining small objects and starting fires in sunlight.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "manacles",
    name: "Manacles",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 15, currency: "gp" },
    weight: 30,
    description: "Iron restraints with a lock for binding prisoners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "marbles-bag",
    name: "Marbles (Bag of 20)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "Glass marbles scattered to trip pursuers.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mining-pick",
    name: "Mining Pick",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 80,
    description: "A heavy pick for breaking rock.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "mirror-small",
    name: "Mirror (Small)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 5,
    description: "A small steel mirror for signalling and peeking around corners.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-stringed",
    name: "Musical Instrument (Stringed)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 30,
    description: "A lute, lyre, or similar stringed instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "musical-instrument-wind",
    name: "Musical Instrument (Wind)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 10,
    description: "A flute, recorder, or similar wind instrument.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "paper-parchment-2-sheets",
    name: "Paper or Parchment (2 Sheets)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 2,
    description: "Two sheets of paper or parchment for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "pole-10ft",
    name: "Pole (10' Long Wooden)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "A ten-foot wooden pole for prodding, vaulting, and bridging gaps.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "quill",
    name: "Quill",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A feather quill for writing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-50ft",
    name: "Rope (50' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 50,
    description: "Fifty feet of hempen rope.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "rope-ladder-25ft",
    name: "Rope Ladder (25' Long)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 50,
    description: "A twenty-five foot rope ladder.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "saw",
    name: "Saw",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A toothed blade for cutting wood.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "shovel",
    name: "Shovel",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 5, currency: "gp" },
    weight: 50,
    description: "An iron-headed shovel for digging.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "spell-book-blank",
    name: "Spell Book (Blank)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 50, currency: "gp" },
    weight: 30,
    description: "A blank tome for recording spells.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "thieves-tools",
    name: "Thieves' Tools",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 30, currency: "gp" },
    weight: 10,
    description: "A set of picks, tension wrenches, and other tools for opening locks.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "twine-100ft",
    name: "Twine (100' Ball)",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 10,
    description: "A ball of one hundred feet of thin twine.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "whistle",
    name: "Whistle",
    category: "Adventuring Gear",
    subcategory: "Tools",
    size: "tiny",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 1,
    description: "A small metal whistle for signalling.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  // ─── ADVENTURING GEAR — CLOTHING ──────────────────────────────────────────
  {
    id: "clothes-common",
    name: "Clothes (Common)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 1, currency: "gp" },
    weight: 30,
    description: "Plain, practical everyday clothing.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-extravagant",
    name: "Clothes (Extravagant)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "large",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 100, currency: "gp" },
    weight: 60,
    description: "Elaborate clothing in silk and velvet, befitting a noble.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "clothes-fine",
    name: "Clothes (Fine)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 20, currency: "gp" },
    weight: 40,
    description: "Quality clothing suitable for merchants and minor gentry.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "habit-friars",
    name: "Habit (Friar's)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 30,
    description: "A simple hooded robe worn by friars and mendicants.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "robes-ritual",
    name: "Robes (Ritual)",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 10, currency: "gp" },
    weight: 30,
    description: "Ceremonial robes worn during religious rites.",
    qualities: [],
    tags: [],
    isCustom: !1
  },
  {
    id: "winter-cloak",
    name: "Winter Cloak",
    category: "Adventuring Gear",
    subcategory: "Clothing",
    size: "normal",
    cannotBeStowed: !1,
    unit: "piece",
    cost: { amount: 2, currency: "gp" },
    weight: 20,
    description: "A heavy wool cloak for cold weather.",
    qualities: [],
    tags: [],
    isCustom: !1
  }
], $ = new Map(
  v.map((s) => [s.id, s])
);
[
  ...new Set(v.map((s) => s.category))
];
[
  ...new Set(v.flatMap((s) => s.tags))
].sort();
class T {
  static getDefinition(e) {
    return $.get(e);
  }
  static getAllDefinitions() {
    return v;
  }
  static getMap() {
    return $;
  }
  static getByCategory(e) {
    return v.filter((t) => t.category === e);
  }
  static getBySubcategory(e) {
    return v.filter((t) => t.subcategory === e);
  }
  /** Returns items that have ALL of the specified tags, plus items with no tags (always visible). */
  static filterByTags(e) {
    return e.length === 0 ? v : v.filter(
      (t) => t.tags.length === 0 || e.every((o) => t.tags.includes(o))
    );
  }
  static getCategories() {
    return [...new Set(v.map((e) => e.category))];
  }
  static getSubcategories(e) {
    const t = e ? v.filter((o) => o.category === e) : v;
    return [...new Set(t.map((o) => o.subcategory))];
  }
  static getAllTags() {
    return [...new Set(v.flatMap((e) => e.tags))].sort();
  }
  /** Group catalog items by category, then subcategory */
  static groupedByCategoryAndSubcategory() {
    const e = {};
    for (const t of v)
      e[t.category] || (e[t.category] = {}), e[t.category][t.subcategory] || (e[t.category][t.subcategory] = []), e[t.category][t.subcategory].push(t);
    return e;
  }
}
const q = class q extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor() {
    super(...arguments);
    /** Currently selected target actor ID */
    A(this, "selectedActorId", null);
    /** Current search/filter text */
    A(this, "searchText", "");
  }
  async _prepareContext(t) {
    var g, f, h;
    const o = game, a = o.settings.get(p, _.SHOP_STATE), n = (((g = o.actors) == null ? void 0 : g.contents) ?? []).filter(
      (u) => {
        var y;
        return (((y = o.users) == null ? void 0 : y.contents) ?? []).some((b) => !b.isGM && u.testUserPermission(b, "OWNER"));
      }
    );
    !this.selectedActorId && n.length > 0 && (this.selectedActorId = n[0].id ?? null);
    const i = this.selectedActorId ? (f = o.actors) == null ? void 0 : f.get(this.selectedActorId) : void 0;
    let r = T.filterByTags(a.activeTags);
    if (a.availableItems.length > 0 && (r = r.filter((u) => a.availableItems.includes(u.id))), this.searchText) {
      const u = this.searchText.toLowerCase();
      r = r.filter(
        (y) => y.name.toLowerCase().includes(u) || y.category.toLowerCase().includes(u) || y.subcategory.toLowerCase().includes(u)
      );
    }
    const c = {};
    for (const u of r)
      c[u.category] || (c[u.category] = []), c[u.category].push(u);
    let l, d;
    return i && (l = m.getInventory(i), d = x(
      l,
      T.getMap()
    )), {
      shopState: a,
      allTags: T.getAllTags(),
      grouped: c,
      partyMembers: n,
      selectedActorId: this.selectedActorId,
      selectedActor: i,
      selectedInventory: l,
      selectedEncumbrance: d,
      searchText: this.searchText,
      isGM: ((h = o.user) == null ? void 0 : h.isGM) ?? !1
    };
  }
  _onRender(t, o) {
    var n, i;
    const a = this.element;
    (n = a.querySelector("#shop-target-actor")) == null || n.addEventListener(
      "change",
      (r) => {
        this.selectedActorId = r.target.value || null, this.render();
      }
    ), (i = a.querySelector("#shop-search")) == null || i.addEventListener(
      "input",
      (r) => {
        this.searchText = r.target.value, this.render();
      }
    );
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static async _onToggleTag(t, o) {
    const a = o.dataset.tag, n = game, i = n.settings.get(p, _.SHOP_STATE), r = i.activeTags.indexOf(a);
    r === -1 ? i.activeTags.push(a) : i.activeTags.splice(r, 1), await n.settings.set(p, _.SHOP_STATE, i), this.render();
  }
  static async _onPurchaseItem(t, o) {
    var y, b;
    const a = o.dataset.itemId, n = T.getDefinition(a);
    if (!n || !this.selectedActorId) return;
    const r = (y = game.actors) == null ? void 0 : y.get(this.selectedActorId);
    if (!r) return;
    const c = m.getInventory(r), l = c.coins.cp + c.coins.sp * 10 + c.coins.gp * 100 + c.coins.pp * 500, d = n.cost.currency === "cp" ? n.cost.amount : n.cost.currency === "sp" ? n.cost.amount * 10 : n.cost.currency === "gp" ? n.cost.amount * 100 : n.cost.amount * 500, g = l >= d;
    if (!await new Promise((w) => {
      new Dialog({
        title: "Purchase Item",
        content: `
          <p>Purchase <strong>${n.name}</strong> for <strong>${n.cost.amount} ${n.cost.currency}</strong>?</p>
          <p>Target: <strong>${r.name}</strong></p>
          ${g ? "" : '<p class="warning"><i class="fas fa-exclamation-triangle"></i> Insufficient funds! Proceed anyway (GM override)?</p>'}
          <div class="form-group">
            <label>Add to zone:</label>
            <select id="purchase-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
        `,
        buttons: {
          confirm: {
            label: g ? "Purchase" : "Override & Purchase",
            icon: `<i class="fas ${g ? "fa-shopping-cart" : "fa-exclamation-triangle"}"></i>`,
            callback: () => w(!0)
          },
          cancel: { label: "Cancel", callback: () => w(!1) }
        },
        default: "confirm"
      }).render(!0);
    })) return;
    const h = "stowed", u = g ? l - d : l;
    await m.updateInventory(r, (w) => (g && (w.coins.gp = Math.floor(u / 100), w.coins.sp = Math.floor(u % 100 / 10), w.coins.cp = u % 10, w.coins.pp = 0), w.items.push({
      id: foundry.utils.randomID(),
      definitionId: a,
      name: n.name,
      quantity: 1,
      zone: h,
      isSecret: !1,
      notes: ""
    }), w)), (b = ui.notifications) == null || b.info(`Purchased ${n.name} for ${r.name}.`), this.render();
  }
  static _onGrantItem(t, o) {
    var i, r;
    const a = o.dataset.itemId, n = T.getDefinition(a);
    if (!n || !this.selectedActorId) {
      (i = ui.notifications) == null || i.warn("Select a party member first.");
      return;
    }
    C.emit(I.GM_GRANT, {
      actorId: this.selectedActorId,
      item: {
        definitionId: a,
        name: n.name,
        quantity: 1,
        zone: "stowed",
        isSecret: !1,
        notes: ""
      }
    }), (r = ui.notifications) == null || r.info(`Granted ${n.name}.`);
  }
  static _onAddCustomItem() {
    var o;
    if (!this.selectedActorId) {
      (o = ui.notifications) == null || o.warn("Select a party member first.");
      return;
    }
    const t = this.selectedActorId;
    new Dialog({
      title: "Add Custom Item",
      content: `
        <form>
          <div class="form-group">
            <label>Item Name</label>
            <input type="text" id="custom-name" placeholder="Custom item name" />
          </div>
          <div class="form-group">
            <label>Size</label>
            <select id="custom-size">
              <option value="tiny">Tiny (0 slots)</option>
              <option value="normal" selected>Normal (1 slot)</option>
              <option value="large">Large (2 slots)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="custom-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="custom-zone">
              <option value="equipped">Equipped</option>
              <option value="stowed" selected>Stowed</option>
              <option value="tiny">Tiny</option>
            </select>
          </div>
          <div class="form-group">
            <label>Secret?</label>
            <input type="checkbox" id="custom-secret" />
          </div>
        </form>
      `,
      buttons: {
        add: {
          label: "Grant Item",
          callback: (a) => {
            const n = a.find("#custom-name").val().trim();
            if (!n) return;
            const i = a.find("#custom-size").val(), r = Math.max(1, parseInt(a.find("#custom-qty").val(), 10) || 1), c = a.find("#custom-zone").val(), l = a.find("#custom-secret").prop("checked");
            C.emit(I.GM_GRANT, {
              actorId: t,
              item: {
                definitionId: "",
                name: n,
                quantity: r,
                zone: c,
                isSecret: l,
                notes: "",
                customDefinition: { size: i, isCustom: !0 }
              }
            });
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    }).render(!0);
  }
};
A(q, "DEFAULT_OPTIONS", {
  id: "dolmenwood-shop",
  window: {
    title: "Shop",
    resizable: !0
  },
  position: {
    width: 700,
    height: 640
  },
  classes: ["dolmenwood-party-inventory", "shop"],
  actions: {
    toggleTag: q._onToggleTag,
    purchaseItem: q._onPurchaseItem,
    grantItem: q._onGrantItem,
    addCustomItem: q._onAddCustomItem
  }
}), A(q, "PARTS", {
  content: {
    template: z.SHOP
  }
});
let O = q;
const S = class S extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  constructor(t, o) {
    super(o);
    A(this, "actor");
    this.actor = t;
  }
  get title() {
    return `${this.actor.name} — Inventory`;
  }
  async _prepareContext(t) {
    var h;
    const o = game, a = m.getInventory(this.actor), n = x(a, T.getMap()), i = ((h = o.user) == null ? void 0 : h.isGM) ?? !1, r = this.actor.isOwner, c = a.items.filter(
      (u) => !u.isSecret || i || r
    ), l = {
      tiny: c.filter((u) => u.zone === "tiny"),
      equipped: c.filter((u) => u.zone === "equipped"),
      stowed: c.filter((u) => u.zone === "stowed")
    }, d = (u) => u.map((y) => ({
      ...y,
      def: T.getDefinition(y.definitionId)
    })), f = o.settings.get(p, "partyActorIds").map((u) => {
      var y;
      return (y = o.actors) == null ? void 0 : y.get(u);
    }).filter((u) => !!u && u.id !== this.actor.id);
    return {
      actor: this.actor,
      actorId: this.actor.id,
      inventory: a,
      zones: {
        tiny: d(l.tiny),
        equipped: d(l.equipped),
        stowed: d(l.stowed)
      },
      encumbrance: n,
      isGM: i,
      isOwner: r,
      canEdit: i || r,
      partyMembers: f,
      transactions: i ? m.getTransactions() : []
    };
  }
  _onRender(t, o) {
    const a = this.element;
    a.querySelectorAll(".item-zone-select").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const r = i.target.dataset.itemId, c = i.target.value;
        await m.updateInventory(this.actor, (l) => {
          const d = l.items.find((g) => g.id === r);
          return d && (d.zone = c), l;
        }), this.render();
      });
    }), a.querySelectorAll(".item-notes-input").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const r = i.target.dataset.itemId, c = i.target.value;
        await m.updateInventory(this.actor, (l) => {
          const d = l.items.find((g) => g.id === r);
          return d && (d.notes = c), l;
        });
      });
    }), a.querySelectorAll(".coin-input").forEach((n) => {
      n.addEventListener("change", async (i) => {
        const r = i.target.dataset.currency, c = Math.max(0, parseInt(i.target.value, 10) || 0);
        await m.updateInventory(this.actor, (l) => (l.coins[r] = c, l)), this.render();
      });
    });
  }
  // ─── Action Handlers ──────────────────────────────────────────────────────
  static async _onIncrementQty(t, o) {
    const a = o.dataset.itemId;
    await m.updateInventory(this.actor, (n) => {
      const i = n.items.find((r) => r.id === a);
      return i && (i.quantity = Math.max(1, i.quantity + 1)), n;
    }), this.render();
  }
  static async _onDecrementQty(t, o) {
    const a = o.dataset.itemId;
    await m.updateInventory(this.actor, (n) => {
      const i = n.items.find((r) => r.id === a);
      return i && (i.quantity = Math.max(1, i.quantity - 1)), n;
    }), this.render();
  }
  static async _onDeleteItem(t, o) {
    const a = o.dataset.itemId;
    await Dialog.confirm({
      title: "Remove Item",
      content: "<p>Remove this item from inventory?</p>"
    }) && (await m.updateInventory(this.actor, (i) => (i.items = i.items.filter((r) => r.id !== a), i)), this.render());
  }
  static async _onToggleSecret(t, o) {
    const a = o.dataset.itemId;
    await m.updateInventory(this.actor, (n) => {
      const i = n.items.find((r) => r.id === a);
      return i && (i.isSecret = !i.isSecret), n;
    }), this.render();
  }
  static _onAddItem(t, o) {
    const a = o.dataset.zone ?? "equipped";
    new X(this.actor, a, () => this.render()).render(!0);
  }
  static _onGiveItem(t, o) {
    const a = o.dataset.itemId;
    new ee(this.actor, a, () => this.render()).render(!0);
  }
};
A(S, "DEFAULT_OPTIONS", {
  id: "dolmenwood-player-inventory",
  window: {
    title: "Inventory",
    resizable: !0
  },
  position: {
    width: 520,
    height: 700
  },
  classes: ["dolmenwood-party-inventory", "player-inventory"],
  actions: {
    addItem: S._onAddItem,
    deleteItem: S._onDeleteItem,
    toggleSecret: S._onToggleSecret,
    giveItem: S._onGiveItem,
    incrementQty: S._onIncrementQty,
    decrementQty: S._onDecrementQty
  }
}), A(S, "PARTS", {
  content: {
    template: z.PLAYER_INVENTORY
  }
});
let R = S;
class X extends Dialog {
  constructor(t, o, a) {
    const n = T.getAllDefinitions(), i = {};
    for (const c of n)
      i[c.category] || (i[c.category] = ""), i[c.category] += `<option value="${c.id}">${c.name} (${c.size}, ${c.cost.amount} ${c.cost.currency})</option>`;
    let r = "";
    for (const [c, l] of Object.entries(i))
      r += `<optgroup label="${c}">${l}</optgroup>`;
    super({
      title: "Add Item to Inventory",
      content: `
        <form>
          <div class="form-group">
            <label>Item</label>
            <select id="add-item-select">${r}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="add-item-qty" value="1" min="1" />
          </div>
          <div class="form-group">
            <label>Zone</label>
            <select id="add-item-zone">
              <option value="equipped" ${o === "equipped" ? "selected" : ""}>Equipped</option>
              <option value="stowed" ${o === "stowed" ? "selected" : ""}>Stowed</option>
              <option value="tiny" ${o === "tiny" ? "selected" : ""}>Tiny</option>
            </select>
          </div>
          <hr/>
          <details>
            <summary>Add Custom Item Instead</summary>
            <div class="form-group">
              <label>Custom Name</label>
              <input type="text" id="add-custom-name" placeholder="Custom item name" />
            </div>
            <div class="form-group">
              <label>Custom Size</label>
              <select id="add-custom-size">
                <option value="tiny">Tiny (0 slots)</option>
                <option value="normal" selected>Normal (1 slot)</option>
                <option value="large">Large (2 slots)</option>
              </select>
            </div>
          </details>
        </form>
      `,
      buttons: {
        add: {
          label: "Add",
          callback: async (c) => {
            const l = c.find("#add-custom-name").val().trim(), d = Math.max(1, parseInt(c.find("#add-item-qty").val(), 10) || 1), g = c.find("#add-item-zone").val();
            if (l) {
              const f = c.find("#add-custom-size").val();
              await m.updateInventory(t, (h) => (h.items.push({
                id: foundry.utils.randomID(),
                definitionId: "",
                name: l,
                quantity: d,
                zone: g,
                isSecret: !1,
                notes: "",
                customDefinition: { size: f, isCustom: !0 }
              }), h));
            } else {
              const f = c.find("#add-item-select").val(), h = T.getDefinition(f);
              if (!h) return;
              await m.updateInventory(t, (u) => (u.items.push({
                id: foundry.utils.randomID(),
                definitionId: f,
                name: h.name,
                quantity: d,
                zone: g,
                isSecret: !1,
                notes: ""
              }), u));
            }
            a();
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "add"
    });
    A(this, "actor");
    A(this, "zone");
    A(this, "onComplete");
    this.actor = t, this.zone = o, this.onComplete = a;
  }
}
class ee extends Dialog {
  constructor(e, t, o) {
    const a = game, r = a.settings.get(p, "partyActorIds").map((d) => {
      var g;
      return (g = a.actors) == null ? void 0 : g.get(d);
    }).filter((d) => !!d && d.id !== e.id).map((d) => `<option value="${d.id}">${d.name}</option>`).join(""), l = m.getInventory(e).items.find((d) => d.id === t);
    l && super({
      title: `Give ${l.name}`,
      content: `
        <form>
          <div class="form-group">
            <label>Give to</label>
            <select id="give-item-target">${r}</select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="give-item-qty" value="1" min="1" max="${l.quantity}" />
          </div>
        </form>
      `,
      buttons: {
        give: {
          label: "Give",
          callback: async (d) => {
            var u;
            const g = d.find("#give-item-target").val(), f = Math.min(
              l.quantity,
              Math.max(1, parseInt(d.find("#give-item-qty").val(), 10) || 1)
            );
            (u = a.actors) != null && u.get(g) && (await m.updateInventory(e, (y) => {
              const b = y.items.find((w) => w.id === t);
              return b && (b.quantity -= f, b.quantity <= 0 && (y.items = y.items.filter((w) => w.id !== t))), y;
            }), C.emit(I.GM_GRANT, {
              actorId: g,
              item: {
                definitionId: l.definitionId,
                name: l.name,
                quantity: f,
                zone: l.zone,
                isSecret: !1,
                notes: "",
                customDefinition: l.customDefinition
              }
            }), o());
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "give"
    });
  }
}
const k = class k extends foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2
) {
  async _prepareContext(e) {
    var i, r;
    const t = game, a = (((i = t.actors) == null ? void 0 : i.contents) ?? []).filter(
      (c) => {
        var l;
        return (((l = t.users) == null ? void 0 : l.contents) ?? []).some((d) => !d.isGM && c.testUserPermission(d, "OWNER"));
      }
    ).map((c) => {
      const l = m.getInventory(c), d = x(l, T.getMap()), g = {};
      for (const f of l.items)
        g[f.zone] || (g[f.zone] = []);
      return {
        actor: c,
        actorId: c.id,
        inventory: l,
        encumbrance: d,
        isOwner: c.isOwner
      };
    }).filter(Boolean), n = {
      cp: 0,
      sp: 0,
      gp: 0,
      pp: 0
    };
    for (const c of a)
      c && (n.cp += c.inventory.coins.cp, n.sp += c.inventory.coins.sp, n.gp += c.inventory.coins.gp, n.pp += c.inventory.coins.pp);
    return {
      members: a,
      partyTotals: n,
      isGM: ((r = t.user) == null ? void 0 : r.isGM) ?? !1,
      transactions: m.getTransactions().slice(-20).reverse()
    };
  }
  _onRender(e, t) {
    this.element.querySelectorAll(".player-column[data-actor-id]").forEach((o) => {
      o.addEventListener("click", (a) => {
        var r;
        if (a.target.closest("button")) return;
        const n = o.dataset.actorId, i = (r = game.actors) == null ? void 0 : r.get(n);
        i && new R(i).render(!0);
      });
    });
  }
  // ─── Action Handlers ────────────────────────────────────────────────────────
  static _onOpenShop() {
    new O().render(!0);
  }
  static _onOpenPlayerInventory(e, t) {
    var n;
    const o = t.dataset.actorId, a = (n = game.actors) == null ? void 0 : n.get(o);
    a && new R(a).render(!0);
  }
};
A(k, "DEFAULT_OPTIONS", {
  id: "dolmenwood-party-overview",
  window: {
    title: "Party Inventory Overview",
    resizable: !0
  },
  position: {
    width: 960,
    height: 620
  },
  classes: ["dolmenwood-party-inventory", "party-overview"],
  actions: {
    openShop: k._onOpenShop,
    openPlayerInventory: k._onOpenPlayerInventory
  }
}), A(k, "PARTS", {
  content: {
    template: z.PARTY_OVERVIEW
  }
});
let L = k;
Hooks.once("init", () => {
  console.log(`${p} | Initializing`), game.settings.register(p, _.SHOP_STATE, {
    name: "Shop State",
    hint: "Active tags and available items for the shop panel.",
    scope: "world",
    config: !1,
    type: Object,
    default: { activeTags: [], availableItems: [] }
  }), game.settings.register(p, E.TRANSACTION_LOG, {
    name: "Transaction Log",
    scope: "world",
    config: !1,
    type: Array,
    default: []
  }), Z();
});
Hooks.once("ready", async () => {
  var t, o;
  console.log(`${p} | Ready`), await K(), C.initialize();
  const s = game.modules.get(p);
  s && (s.api = {
    openPartyOverview: () => F(),
    openPlayerInventory: (a) => W(a),
    openShop: () => te()
  });
  const e = game;
  !((t = e.user) != null && t.isGM) && ((o = e.user) != null && o.character) && W(e.user.character);
});
Hooks.on("updateActor", (s, e) => {
  var a, n, i, r;
  if (!((a = e.flags) == null ? void 0 : a[p])) return;
  const o = (n = foundry.applications) == null ? void 0 : n.instances;
  if (o)
    for (const c of o.values()) {
      const l = c.id ?? "";
      if (l === "dolmenwood-party-overview")
        (i = c.render) == null || i.call(c);
      else if (l === "dolmenwood-player-inventory") {
        const d = c;
        ((r = d.actor) == null ? void 0 : r.id) === s.id && d.render();
      }
    }
});
Hooks.on("getSceneControlButtons", (s) => {
  var o;
  if (!((o = game.user) != null && o.isGM)) return;
  const t = s.tokens;
  t && (t.tools["dolmenwood-party-inventory"] = {
    name: "dolmenwood-party-inventory",
    title: "Party Inventory",
    icon: "fas fa-backpack",
    order: Object.keys(t.tools).length,
    button: !0,
    onChange: () => F()
  });
});
function F() {
  var t, o;
  if (!((t = game.user) != null && t.isGM)) {
    (o = ui.notifications) == null || o.warn("Only the GM can access the Party Overview.");
    return;
  }
  const e = H("dolmenwood-party-overview");
  e ? e.render({ force: !0 }) : new L().render(!0);
}
function W(s) {
  var a, n, i;
  const e = game;
  let t;
  if (typeof s == "string" ? t = (a = e.actors) == null ? void 0 : a.get(s) : s instanceof Actor ? t = s : t = ((n = e.user) == null ? void 0 : n.character) ?? void 0, !t) {
    (i = ui.notifications) == null || i.warn("No actor found. Assign a character to your user first.");
    return;
  }
  const o = H("dolmenwood-player-inventory");
  o ? o.render({ force: !0 }) : new R(t).render(!0);
}
function te() {
  var t, o;
  if (!((t = game.user) != null && t.isGM)) {
    (o = ui.notifications) == null || o.warn("Only the GM can open the Shop.");
    return;
  }
  const e = H("dolmenwood-shop");
  e ? e.render({ force: !0 }) : new O().render(!0);
}
function H(s) {
  var t;
  const e = (t = foundry.applications) == null ? void 0 : t.instances;
  if (e) {
    for (const o of e.values())
      if (o.id === s)
        return o;
  }
}
//# sourceMappingURL=module.js.map
